# Exact-binary CUDA inspection

Static SASS instruction counts describe the compiled instruction listing, not executed instructions, dynamic spill traffic, or elapsed-time attribution. Loops, branch paths and predication change runtime counts.

Register and local-memory sizes are compiled resource declarations. LDL/STL indicate local-memory instructions; local memory can have purposes besides spills.

Requested architecture: `sm_89`. Only that architecture is included in the comparison table.

| Backend | Kernel | Architecture | Registers | Stack bytes | Local bytes | Static inst. | Integer | IADD3 | IMAD | IMAD.WIDE | LDL | STL |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| canonical | fwd, template index=int | sm_89 | 42 | 0 | 0 | 304 | 205 | 39 | 99 | 9 | 0 | 0 |
| canonical | fwd, template index=long | sm_89 | 55 | 0 | 0 | 616 | 414 | 90 | 195 | 26 | 0 | 0 |
| canonical | bwd, C=32 | sm_89 | 70 | 0 | 0 | 472 | 174 | 66 | 49 | 8 | 0 | 0 |
| canonical | bwd, C=32 | sm_89 | 74 | 0 | 0 | 624 | 293 | 97 | 111 | 17 | 0 | 0 |
| canonical_before | fwd, template index=int | sm_89 | 54 | 0 | 0 | 504 | 328 | 62 | 137 | 20 | 0 | 0 |
| canonical_before | fwd, template index=long | sm_89 | 55 | 0 | 0 | 624 | 419 | 82 | 197 | 26 | 0 | 0 |
| canonical_before | bwd, C=32 | sm_89 | 74 | 0 | 0 | 632 | 298 | 94 | 113 | 17 | 0 | 0 |
| hf | fwd, template index=absent | sm_89 | 39 | 0 | 0 | 240 | 148 | 26 | 70 | 5 | 0 | 0 |
| hf | bwd, C=32 | sm_89 | 47 | 0 | 0 | 432 | 148 | 62 | 34 | 7 | 0 | 0 |

## Binary provenance

- `canonical`: `/workspace/ci/profile-env/lib/python3.11/site-packages/torch_ms_deform_attn/_C.cpython-311-x86_64-linux-gnu.so`; SHA256 `a50ce0bb1ddb6ac6f2cb9a82c4c4ce886c63872edafe960e2cb0ff610408054f`; measured-report hash match: `True`.
- `canonical_before`: `/workspace/ci/before/diagnostic-build/msda_pr16_before_C.so`; SHA256 `32c1854b1cdd0fc785143c8579b5b66ec9704d85f0eb5a9aed500cf1c684e18f`; measured-report hash match: `True`.
- `hf`: `/home/ci/.cache/huggingface/hub/blobs/7d/7d2a02fde1afb32bee02103a78562d1d7e71a0be3ac3b0f1848c5303d8c89a79`; SHA256 `1a5053e022f3e5840ca9f40d361b5356ef0beeefdd8686029378dd4a7284b959`; measured-report hash match: `True`.
