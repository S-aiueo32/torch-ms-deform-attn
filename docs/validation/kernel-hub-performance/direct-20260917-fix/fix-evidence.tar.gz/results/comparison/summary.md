# PR #16 CUDA profiling summary

GPU: NVIDIA L4; PyTorch: 2.10.0+cu126; CUDA: 12.6.

Status: complete.
Wall and graph times are microseconds. Values are medians of repeat medians; ratios above 1 are slower than the named reference. Baseline reference: `canonical_before`.

Graph timing largely removes Python/dispatcher enqueue overhead, but includes GPU casts, allocations captured as operations, fills and kernels. Wall minus graph is not a direct measurement of host overhead.

HF exact requested revision loaded: `True`; loader arguments: `{"revision": "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"}`.

## decoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 64.66 [63.90, 65.06] | 58.84 | 1.000 | 1.000 | 0.959 | 0.939 |
| canonical | 7 | 64.83 [64.63, 64.95] | 59.90 | 1.003 | 1.018 | 0.961 | 0.955 |
| native_control | 7 | 64.55 [64.38, 64.91] | 59.90 | 0.998 | 1.018 | 0.957 | 0.955 |
| before_native | 7 | 67.27 [67.21, 67.51] | 62.71 | 1.040 | 1.066 | 0.997 | 1.000 |
| canonical_before | 7 | 67.45 [66.97, 67.51] | 62.70 | 1.043 | 1.066 | 1.000 | 1.000 |

## decoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 367.89 [228.52, 414.52] | 175.83 | 1.000 | 1.000 | 1.276 | 0.913 |
| canonical | 7 | 252.96 [229.58, 326.91] | 198.03 | 0.688 | 1.126 | 0.877 | 1.029 |
| native_control | 7 | 260.62 [230.62, 320.21] | 194.56 | 0.708 | 1.106 | 0.904 | 1.011 |
| before_native | 7 | 240.60 [235.35, 335.10] | 205.15 | 0.654 | 1.167 | 0.834 | 1.066 |
| canonical_before | 7 | 288.35 [263.69, 380.95] | 192.49 | 0.784 | 1.095 | 1.000 | 1.000 |

## decoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 39.27 [39.11, 39.97] | 36.75 | 1.000 | 1.000 | 0.921 | 0.905 |
| canonical | 7 | 39.75 [39.68, 40.25] | 38.17 | 1.012 | 1.039 | 0.933 | 0.940 |
| native_control | 7 | 40.04 [39.49, 40.16] | 38.09 | 1.020 | 1.037 | 0.939 | 0.938 |
| before_native | 7 | 42.59 [42.07, 42.71] | 40.23 | 1.085 | 1.095 | 0.999 | 0.990 |
| canonical_before | 7 | 42.62 [41.71, 42.94] | 40.62 | 1.085 | 1.105 | 1.000 | 1.000 |

## decoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 165.02 [162.56, 181.73] | 149.87 | 1.000 | 1.000 | 0.795 | 0.994 |
| canonical | 7 | 164.38 [162.37, 170.75] | 153.42 | 0.996 | 1.024 | 0.792 | 1.018 |
| native_control | 7 | 164.07 [162.42, 165.85] | 152.46 | 0.994 | 1.017 | 0.790 | 1.011 |
| before_native | 7 | 169.20 [168.69, 170.95] | 159.92 | 1.025 | 1.067 | 0.815 | 1.061 |
| canonical_before | 7 | 207.66 [189.93, 289.73] | 150.74 | 1.258 | 1.006 | 1.000 | 1.000 |

## encoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 738.19 [735.09, 740.51] | 728.71 | 1.000 | 1.000 | 0.912 | 0.908 |
| canonical | 7 | 777.15 [771.46, 778.53] | 768.88 | 1.053 | 1.055 | 0.960 | 0.958 |
| native_control | 7 | 775.32 [770.49, 777.92] | 762.81 | 1.050 | 1.047 | 0.957 | 0.951 |
| before_native | 7 | 808.94 [808.49, 815.36] | 801.02 | 1.096 | 1.099 | 0.999 | 0.998 |
| canonical_before | 7 | 809.84 [808.88, 815.36] | 802.35 | 1.097 | 1.101 | 1.000 | 1.000 |

## encoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 3016.60 [3006.66, 3032.80] | 3110.70 | 1.000 | 1.000 | 0.946 | 0.953 |
| canonical | 7 | 3091.79 [3073.87, 3093.53] | 3165.81 | 1.025 | 1.018 | 0.970 | 0.970 |
| native_control | 7 | 3092.02 [3065.16, 3093.96] | 3162.61 | 1.025 | 1.017 | 0.970 | 0.969 |
| before_native | 7 | 3184.69 [3179.60, 3187.28] | 3271.13 | 1.056 | 1.052 | 0.999 | 1.002 |
| canonical_before | 7 | 3187.57 [3184.14, 3189.45] | 3265.30 | 1.057 | 1.050 | 1.000 | 1.000 |

## encoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 600.46 [599.53, 606.81] | 601.21 | 1.000 | 1.000 | 0.896 | 0.910 |
| canonical | 7 | 633.12 [632.46, 634.30] | 629.24 | 1.054 | 1.047 | 0.944 | 0.952 |
| native_control | 7 | 632.39 [628.60, 633.55] | 624.13 | 1.053 | 1.038 | 0.943 | 0.944 |
| before_native | 7 | 670.43 [668.71, 671.78] | 665.33 | 1.117 | 1.107 | 1.000 | 1.007 |
| canonical_before | 7 | 670.46 [668.76, 672.05] | 660.82 | 1.117 | 1.099 | 1.000 | 1.000 |

## encoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 2909.46 [2908.77, 2911.39] | 2983.16 | 1.000 | 1.000 | 0.956 | 0.957 |
| canonical | 7 | 2930.36 [2927.55, 2957.94] | 3018.01 | 1.007 | 1.012 | 0.963 | 0.968 |
| native_control | 7 | 2927.22 [2925.51, 2928.36] | 3008.95 | 1.006 | 1.009 | 0.962 | 0.965 |
| before_native | 7 | 3041.00 [3018.44, 3048.41] | 3092.05 | 1.045 | 1.037 | 1.000 | 0.992 |
| canonical_before | 7 | 3042.18 [3014.92, 3044.18] | 3116.51 | 1.046 | 1.045 | 1.000 | 1.000 |

Correctness: 20/20 backend/case/dtype qualifications passed.
