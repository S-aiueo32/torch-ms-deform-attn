
#include <ATen/ATen.h>
#include <torch/csrc/utils/pybind.h>
#include <pybind11/stl.h>
#include "cuda/index_utils.h"

at::Tensor ms_deform_attn_cuda_forward(
    const at::Tensor &, const at::Tensor &, const at::Tensor &,
    const at::Tensor &, const at::Tensor &, const int);
std::vector<at::Tensor> ms_deform_attn_cuda_backward(
    const at::Tensor &, const at::Tensor &, const at::Tensor &,
    const at::Tensor &, const at::Tensor &, const at::Tensor &, const int);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
  module.def("forward", &ms_deform_attn_cuda_forward);
  module.def("backward", &ms_deform_attn_cuda_backward);
  module.def("check_indexing", &ms_deform_attn::check_cuda_indexing);
}
