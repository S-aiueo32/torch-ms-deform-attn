# PR #16 CUDA profiling summary

GPU: NVIDIA L4; PyTorch: 2.10.0+cu126; CUDA: 12.6.

Status: complete.
Wall and graph times are microseconds. Values are medians of repeat medians; ratios above 1 are slower than the named reference. Baseline reference: `canonical_before`.

Graph timing largely removes Python/dispatcher enqueue overhead, but includes GPU casts, allocations captured as operations, fills and kernels. Wall minus graph is not a direct measurement of host overhead.

HF exact requested revision loaded: `True`; loader arguments: `{"revision": "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"}`.

## tiny_host / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 140.76 [125.18, 217.43] | 9.25 | 1.000 | 1.000 | 0.687 | 1.068 |
| canonical | 7 | 167.40 [109.71, 183.54] | 8.56 | 1.189 | 0.926 | 0.817 | 0.989 |
| native_control | 7 | 144.34 [81.38, 188.19] | 8.59 | 1.025 | 0.928 | 0.705 | 0.991 |
| canonical_before | 7 | 204.78 [171.12, 269.29] | 8.66 | 1.455 | 0.936 | 1.000 | 1.000 |

Correctness: 4/4 backend/case/dtype qualifications passed.
