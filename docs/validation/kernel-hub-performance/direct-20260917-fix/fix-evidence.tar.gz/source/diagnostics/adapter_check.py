#!/usr/bin/env python3
"""Validate actual Kernel Hub C++ binding under an independent CUDA namespace.

This exports the working source tree and builds the actual torch_binding.cpp and
CUDA source with cpp_extension.load. It synthesizes only the builder-generated
Python _ops module. It does not test the HF loader or CMake/Nix builder pipeline.
The pinned published HF baseline is deliberately outside this diagnostic scope.
"""

import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import traceback
import unittest

import torch


def digest(path):
    path = Path(path)
    sha = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(4 * 1024 * 1024):
            sha.update(chunk)
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": sha.hexdigest()}


def load_module(name, path, package=False):
    kwargs = {"submodule_search_locations": [str(Path(path).parent)]} if package else {}
    spec = importlib.util.spec_from_file_location(name, path, **kwargs)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def input_tensors():
    shapes = torch.tensor([[2, 3], [1, 2]], device="cuda")
    starts = torch.tensor([0, 6], device="cuda")
    value = torch.randn(2, 8, 2, 4, device="cuda", requires_grad=True)
    scale = shapes.flip(-1).reshape(1, 1, 1, 2, 1, 2)
    pixels = (torch.rand(2, 3, 2, 2, 2, 2, device="cuda") * (scale - 1)).floor() + 0.75
    loc = (pixels / scale).requires_grad_()
    weights = torch.rand(2, 3, 2, 2, 2, device="cuda", requires_grad=True)
    return value, shapes, starts, loc, weights


def values_and_grads(fn, args, grad):
    out = fn(*args)
    grads = torch.autograd.grad(out, (args[0], args[3], args[4]), grad)
    return out.detach(), *grads


def check_tensors(actual, expected):
    errors = {}
    for name, a, b in zip(("output", "grad_value", "grad_locations", "grad_weights"), actual, expected):
        torch.testing.assert_close(a.double(), b.double(), atol=2e-4, rtol=2e-4)
        errors[name] = {"max_abs": (a.double() - b.double()).abs().max().item(), "passed": True}
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("/workspace/ci/source"))
    parser.add_argument("--output-dir", type=Path, default=Path("/workspace/ci/results/adapter"))
    parser.add_argument("--registration-header", type=Path, default=Path(__file__).with_name("registration.h"))
    parser.add_argument("--revision", help="Full source base SHA; exported source hashes identify working-tree changes")
    parser.add_argument("--namespace", default="msda_adapter_diagnostic")
    parser.add_argument("--max-jobs", type=int, default=2)
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument("--build", action="store_true", help="Build and check (also the default)")
    actions.add_argument("--check-only", action="store_true", help="Load previous build manifest and rerun checks")
    parser.add_argument("--build-only", action="store_true", help="Stop after successful export/build")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_]*", args.namespace):
        parser.error("namespace must be a valid C++ identifier")
    if not args.check_only and not args.revision:
        parser.error("--revision is required when building an exported archive")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU required; skipping is not validation")
    args.repo = args.repo.resolve()
    args.output_dir = args.output_dir.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    torch.manual_seed(29)
    stream = torch.cuda.Stream()
    torch.cuda.set_stream(stream)
    report = {
        "config": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
        "environment": {"python": sys.version, "torch": torch.__version__, "cuda": torch.version.cuda,
                        "gpu": torch.cuda.get_device_name(), "capability": torch.cuda.get_device_capability()},
        "scope": {
            "actual_sources": "Exported kernel-hub/torch-ext/torch_binding.cpp, shared dispatcher.h, CUDA implementation, exported Python API",
            "synthesized": "Builder-generated Python _ops import/namespace helper only",
            "excluded": ["HF get_kernel loader", "CMake/Nix builder", "published HF baseline comparison"],
            "namespace_coexistence": "Canonical package and independent native C++ adapter are loaded in the same process",
        },
        "checks": {},
    }
    start = time.monotonic()

    def save():
        path = args.output_dir / "adapter-check.json"
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(report, indent=2) + "\n")
        temporary.replace(path)

    try:
        from torch_ms_deform_attn import _C, ms_deform_attn
        from torch_ms_deform_attn._ops import backward as canonical_backward, forward as canonical_forward
        report["canonical_binary"] = digest(_C.__file__)
        manifest_path = args.output_dir / "build-manifest.json"
        if args.check_only:
            manifest = json.loads(manifest_path.read_text())
            if manifest["namespace"] != args.namespace:
                raise RuntimeError("Namespace differs from recorded build manifest")
            export_root = Path(manifest["export_root"])
            binary = Path(manifest["binary"]["path"])
            if digest(binary)["sha256"] != manifest["binary"]["sha256"]:
                raise RuntimeError("Compiled binding binary changed since build manifest")
            native = load_module(args.namespace, binary)
        else:
            exporter = load_module("msda_adapter_exporter", args.repo / "kernel-hub/export.py")
            export_root = args.output_dir / "export"
            exporter.export(export_root, revision=args.revision)
            include_dir = args.output_dir / "builder-include"
            include_dir.mkdir()
            shutil.copyfile(args.registration_header, include_dir / "registration.h")
            build_dir = args.output_dir / "build"
            build_dir.mkdir()
            os.environ["MAX_JOBS"] = str(args.max_jobs)
            capability = torch.cuda.get_device_capability()
            os.environ.setdefault("TORCH_CUDA_ARCH_LIST", f"{capability[0]}.{capability[1]}")
            from torch.utils.cpp_extension import load
            native = load(
                name=args.namespace,
                sources=[str(export_root / "torch-ext/torch_binding.cpp"),
                         str(export_root / "csrc/cuda/ms_deform_attn_cuda.cu")],
                extra_include_paths=[str(export_root / "csrc"), str(include_dir)],
                extra_cflags=["-O3"], extra_cuda_cflags=["-O3"],
                build_directory=str(build_dir), with_cuda=True, verbose=True,
            )
            sys.modules[args.namespace] = native
            manifest = {"namespace": args.namespace, "export_root": str(export_root),
                        "binary": digest(native.__file__), "registration_header": digest(include_dir / "registration.h"),
                        "upstream": json.loads((export_root / "UPSTREAM.json").read_text()),
                        "torch_cuda_arch_list": os.environ["TORCH_CUDA_ARCH_LIST"],
                        "compiler_flags": {"cxx": ["-O3"], "nvcc": ["-O3"]}}
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        report["build"] = manifest
        report["build_elapsed_seconds"] = time.monotonic() - start
        save()
        if args.build_only:
            report["completed_build_only"] = True
            save()
            return

        package = export_root / "torch-ext/deformable_detr"
        # This is the only synthesized Python component. The C++ operator
        # namespace is registered by the actual torch_binding.cpp above.
        wrapper = package / "_ops.py"
        wrapper_source = (
            "import torch\n"
            f"ops = getattr(torch.ops, {args.namespace!r})\n\n"
            "def add_op_namespace_prefix(name):\n"
            f"    return {args.namespace + '::'!r} + name\n"
        )
        if args.check_only and wrapper.exists() and wrapper.read_text() != wrapper_source:
            raise RuntimeError("Generated Python wrapper differs from requested namespace")
        wrapper.write_text(wrapper_source)
        report["generated_ops_wrapper"] = digest(wrapper)
        adapter = load_module("msda_adapter_python", package / "__init__.py", package=True)
        adapter_forward = adapter._registrations.forward
        adapter_backward = adapter._registrations.backward
        report["operator_names"] = {
            "canonical_forward": canonical_forward._schema.name,
            "canonical_backward": canonical_backward._schema.name,
            "adapter_forward": adapter_forward._schema.name,
            "adapter_backward": adapter_backward._schema.name,
        }
        assert adapter_forward._schema.name == args.namespace + "::forward"
        assert adapter_backward._schema.name == args.namespace + "::backward"
        assert adapter_forward != canonical_forward and adapter_backward != canonical_backward
        report["checks"]["independent_namespaces"] = True

        # Execute the existing test methods, replacing only their HF loader setup
        # with this explicitly built adapter. Their assertions remain unchanged.
        existing_tests = load_module("msda_adapter_existing_tests", export_root / "tests/test_kernel.py")

        class LocalBindingTests(existing_tests.KernelTest):
            @classmethod
            def setUpClass(cls):
                cls.kernel = adapter

        suite = unittest.TestSuite(LocalBindingTests(name) for name in (
            "test_autocast_and_validation", "test_layer",
        ))
        stream_log = io.StringIO()
        result = unittest.TextTestRunner(stream=stream_log, verbosity=2).run(suite)
        text_log = stream_log.getvalue()
        (args.output_dir / "existing-tests.log").write_text(text_log)
        print(text_log, flush=True)
        report["checks"]["existing_kernel_tests"] = {
            "tests_run": result.testsRun, "successful": result.wasSuccessful(),
            "failures": [(str(test), detail) for test, detail in result.failures],
            "errors": [(str(test), detail) for test, detail in result.errors],
            "skipped": [(str(test), detail) for test, detail in result.skipped],
        }
        save()
        if not result.wasSuccessful() or result.skipped:
            raise RuntimeError("Existing adapter tests failed or skipped")

        data = input_tensors()
        grad = torch.randn(2, 3, 8, device="cuda")
        truth = existing_tests.double_reference(data, grad)
        adapter_actual = values_and_grads(adapter.ms_deform_attn, data, grad)
        canonical_actual = values_and_grads(ms_deform_attn, data, grad)
        report["checks"]["adapter_fp64_output_all_gradients"] = check_tensors(adapter_actual, truth)
        report["checks"]["canonical_fp64_output_all_gradients"] = check_tensors(canonical_actual, truth)
        report["checks"]["canonical_adapter_parity"] = check_tensors(adapter_actual, canonical_actual)

        # Capture real AOT forward and backward graphs. Both independent native
        # namespaces must survive when called together in the same full graph.
        from functorch.compile import make_boxed_func
        from torch._dynamo.backends.common import aot_autograd
        graphs = {"forward": [], "backward": []}

        def compiler(kind):
            def compile_graph(gm, example_inputs):
                graphs[kind].append(gm)
                return make_boxed_func(gm.forward)
            return compile_graph

        backend = aot_autograd(fw_compiler=compiler("forward"), bw_compiler=compiler("backward"))

        def combined(*values):
            return ms_deform_attn(*values) + adapter.ms_deform_attn(*values)

        compiled = torch.compile(combined, backend=backend, fullgraph=True)
        combined_actual = values_and_grads(compiled, data, grad)
        report["checks"]["compiled_combined_output_all_gradients"] = check_tensors(
            combined_actual, tuple(tensor * 2 for tensor in truth))
        targets = {kind: [node.target for gm in items for node in gm.graph.nodes]
                   for kind, items in graphs.items()}
        assert canonical_forward in targets["forward"] and adapter_forward in targets["forward"]
        assert canonical_backward in targets["backward"] and adapter_backward in targets["backward"]
        report["checks"]["aot_graph_namespaces"] = {
            kind: [str(target) for target in items] for kind, items in targets.items()
        }
        for kind, items in graphs.items():
            for index, gm in enumerate(items):
                (args.output_dir / f"aot-{kind}-{index}.txt").write_text(str(gm.graph))
        torch.cuda.synchronize()
        report["completed"] = True
        report["elapsed_seconds"] = time.monotonic() - start
        save()
        print(json.dumps({"completed": True, "report": str(args.output_dir / "adapter-check.json"),
                          "elapsed_seconds": report["elapsed_seconds"]}), flush=True)
    except Exception:
        report["error"] = traceback.format_exc()
        report["elapsed_seconds"] = time.monotonic() - start
        save()
        raise


if __name__ == "__main__":
    main()
