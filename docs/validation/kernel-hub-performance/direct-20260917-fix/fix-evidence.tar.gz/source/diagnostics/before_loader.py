"""Load the unchanged PR16 implementation in an isolated operator namespace."""
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

ROOT = Path('/workspace/ci/before')
NAMESPACE = 'msda_pr16_before'
MODULE = 'msda_pr16_before_C'

def load_before():
    existing = sys.modules.get(f'{NAMESPACE}.functional')
    if existing is not None:
        return existing.ms_deform_attn, sys.modules[f'{NAMESPACE}._C']
    build = ROOT / 'diagnostic-build'
    build.mkdir(exist_ok=True)
    binding = build / 'vision.cpp'
    source = (ROOT / 'csrc/vision.cpp').read_text()
    source = source.replace('TORCH_LIBRARY(torch_ms_deform_attn, ops)', f'TORCH_LIBRARY({NAMESPACE}, ops)')
    binding.write_text(source)
    record = build / 'extension.json'
    if record.exists():
        data = json.loads(record.read_text())
        spec = importlib.util.spec_from_file_location(MODULE, data['path'])
        native = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(native)
    else:
        from torch.utils.cpp_extension import load
        os.environ.setdefault('MAX_JOBS', '2')
        native = load(name=MODULE, sources=[str(binding), str(ROOT / 'csrc/ms_deform_attn_cpu.cpp'), str(ROOT / 'csrc/cuda/ms_deform_attn_cuda.cu')],
                      extra_include_paths=[str(ROOT), str(ROOT / 'csrc')],
                      extra_cflags=['-O3', '-DWITH_CUDA'], extra_cuda_cflags=['-O3'],
                      build_directory=str(build), verbose=True, with_cuda=True)
        record.write_text(json.dumps({'path': native.__file__, 'revision': '2d604d2d9e2871ce2dc957278bbdae211e4b3fa8', 'namespace': NAMESPACE}, indent=2) + '\n')
    package_path = ROOT / 'src/torch_ms_deform_attn'
    package = types.ModuleType(NAMESPACE)
    package.__path__ = [str(package_path)]
    package._C = native
    sys.modules[NAMESPACE] = package
    sys.modules[f'{NAMESPACE}._C'] = native
    ops_path = package_path / '_ops.py'
    ops_source = ops_path.read_text().replace('"torch_ms_deform_attn::', f'"{NAMESPACE}::')
    ops = types.ModuleType(f'{NAMESPACE}._ops')
    ops.__package__ = NAMESPACE
    ops.__file__ = str(ops_path)
    sys.modules[ops.__name__] = ops
    exec(compile(ops_source, str(ops_path), 'exec'), ops.__dict__)
    return importlib.import_module(f'{NAMESPACE}.functional').ms_deform_attn, native

if __name__ == '__main__':
    _, native = load_before()
    print(native.__file__)
