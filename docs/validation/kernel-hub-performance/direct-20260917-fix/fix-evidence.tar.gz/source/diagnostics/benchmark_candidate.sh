#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
export PATH=/workspace/ci/profile-env/bin:$PATH
export PYTHONUNBUFFERED=1 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9 CUDA_HOME=/usr/local/cuda
python diagnostics/probe_candidate.py --output-dir /workspace/ci/results/comparison \
  --cases decoder encoder --dtypes float32 float16 \
  --backends canonical canonical_before native_control before_native hf \
  --repeats 7 --min-run-time 0.6 --skip-profile > /workspace/ci/results/comparison.log 2>&1
python diagnostics/summarize.py /workspace/ci/results/comparison/report.json --baseline canonical_before --quiet
python diagnostics/probe_candidate.py --output-dir /workspace/ci/results/host-comparison \
  --cases tiny_host --dtypes float32 --modes forward_backward \
  --backends canonical canonical_before native_control hf \
  --repeats 7 --min-run-time 0.4 --skip-profile > /workspace/ci/results/host-comparison.log 2>&1
python diagnostics/summarize.py /workspace/ci/results/host-comparison/report.json --baseline canonical_before --quiet
printf 'BENCHMARK COMPLETE\n'
