#!/usr/bin/env python3
"""Rapidly interleaved paired CUDA confirmation; no profiler in this process."""

import argparse
import gc
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import time
import traceback

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
import torch
import probe_candidate  # Installs unchanged-PR16 loader and tiny_host input case.
import probe


def proc_stat():
    raw = Path("/proc/stat").read_text()
    cpus = {}
    for line in raw.splitlines():
        fields = line.split()
        if fields and fields[0].startswith("cpu") and fields[0][3:].isdigit():
            cpus[int(fields[0][3:])] = [int(x) for x in fields[1:]]
    return raw, cpus


def topology(cpu):
    root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
    try:
        return ((root / "physical_package_id").read_text().strip(),
                (root / "core_id").read_text().strip())
    except OSError:
        return ("unknown", str(cpu))


def choose_cpus(output, no_pin):
    allowed = sorted(os.sched_getaffinity(0))
    before_raw, before = proc_stat()
    time.sleep(0.25)
    after_raw, after = proc_stat()
    (output / "proc-stat-selection-before.txt").write_text(before_raw)
    (output / "proc-stat-selection-after.txt").write_text(after_raw)
    scored = []
    for cpu in allowed:
        a, b = before[cpu], after[cpu]
        # guest/guest_nice already appear in user/nice: exclude their duplicates.
        total = sum(b[:8]) - sum(a[:8])
        idle = (b[3] + b[4]) - (a[3] + a[4])
        busy = 1.0 - idle / total if total else 1.0
        scored.append({"cpu": cpu, "busy_fraction": busy, "topology": topology(cpu)})
    scored.sort(key=lambda row: (row["busy_fraction"], row["cpu"]))
    chosen, physical = [], set()
    for row in scored:
        if tuple(row["topology"]) not in physical:
            chosen.append(row["cpu"])
            physical.add(tuple(row["topology"]))
        if len(chosen) == min(2, len(allowed)):
            break
    changed = []
    failures = []
    if not no_pin:
        # Apply to existing threads too; later CUDA workers inherit this mask.
        for task in Path("/proc/self/task").iterdir():
            try:
                os.sched_setaffinity(int(task.name), chosen)
                changed.append(int(task.name))
            except (OSError, ProcessLookupError) as exc:
                failures.append({"tid": int(task.name), "error": repr(exc)})
    return {"original_allowed": allowed, "selected": chosen, "pinned": not no_pin,
            "changed_threads": changed, "failures": failures, "load_sample_seconds": 0.25,
            "load_selection": scored, "active_affinity": sorted(os.sched_getaffinity(0))}


def clocks(cpus):
    command = ["nvidia-smi", "--query-gpu=timestamp,pstate,clocks.sm,clocks.mem,power.draw,temperature.gpu,utilization.gpu,utilization.memory",
               "--format=csv"]
    completed = subprocess.run(command, text=True, capture_output=True, check=False, timeout=10)
    cpu = {}
    for number in cpus:
        root = Path(f"/sys/devices/system/cpu/cpu{number}/cpufreq")
        cpu[str(number)] = {}
        for name in ("scaling_cur_freq", "cpuinfo_cur_freq", "scaling_governor"):
            try:
                cpu[str(number)][name] = (root / name).read_text().strip()
            except OSError:
                pass
    return {"gpu_command": command, "gpu_returncode": completed.returncode,
            "gpu_stdout": completed.stdout, "gpu_stderr": completed.stderr, "cpu": cpu}


def stats(values):
    values = sorted(values)
    quantiles = statistics.quantiles(values, n=4, method="inclusive")
    return {"count": len(values), "median": statistics.median(values),
            "p25": quantiles[0], "p75": quantiles[2], "iqr": quantiles[2] - quantiles[0],
            "min": values[0], "max": values[-1]}


def block(run, calls):
    torch.cuda.synchronize()
    wall_start = time.perf_counter_ns()
    cpu_start = time.process_time_ns()
    for _ in range(calls):
        run()
    torch.cuda.synchronize()
    cpu_end = time.process_time_ns()
    wall_end = time.perf_counter_ns()
    return {"wall_us": (wall_end - wall_start) / (1000 * calls),
            "process_cpu_us": (cpu_end - cpu_start) / (1000 * calls)}


def summarize_case(case):
    names = list(case["qualified_backends"])
    result = {"backends": {}, "paired": {}}
    for name in names:
        wall = [row["backends"][name]["wall_us"] for row in case["paired_rounds"]]
        cpu = [row["backends"][name]["process_cpu_us"] for row in case["paired_rounds"]]
        graph = [row["backends"][name]["event_us"] for row in case["graph_rounds"]]
        result["backends"][name] = {
            "wall_us": stats(wall), "process_cpu_us": stats(cpu), "graph_us": stats(graph),
            "epoch_wall_medians_us": [statistics.median(
                row["backends"][name]["wall_us"] for row in case["paired_rounds"] if row["epoch"] == epoch
            ) for epoch in range(case["epochs_completed"])],
        }
    for other in names:
        if other == "canonical":
            continue
        pairs = [(row["backends"]["canonical"]["wall_us"], row["backends"][other]["wall_us"])
                 for row in case["paired_rounds"]]
        graph_pairs = [(row["backends"]["canonical"]["event_us"], row["backends"][other]["event_us"])
                       for row in case["graph_rounds"]]
        result["paired"]["canonical_vs_" + other] = {
            "wall_ratio_new_over_other": stats([a / b for a, b in pairs]),
            "wall_difference_new_minus_other_us": stats([a - b for a, b in pairs]),
            "wall_faster_rounds": sum(a < b for a, b in pairs), "wall_rounds": len(pairs),
            "graph_ratio_new_over_other": stats([a / b for a, b in graph_pairs]),
            "graph_faster_rounds": sum(a < b for a, b in graph_pairs), "graph_rounds": len(graph_pairs),
        }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seconds-per-case", type=float, default=30.0)
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--calls-per-block", type=int, default=10)
    parser.add_argument("--seed", type=int, default=37)
    parser.add_argument("--no-pin", action="store_true")
    args = parser.parse_args()
    if args.epochs < 2 or args.calls_per_block < 1 or args.seconds_per_case <= 0:
        parser.error("Need epochs>=2, calls-per-block>=1 and positive time")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    affinity = choose_cpus(args.output_dir, args.no_pin)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU required")
    stream = torch.cuda.Stream()
    torch.cuda.set_stream(stream)
    torch.manual_seed(args.seed)
    rng = random.Random(args.seed)
    report = {
        "config": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
        "environment": {"python": sys.version, "torch": torch.__version__, "cuda": torch.version.cuda,
                        "gpu": torch.cuda.get_device_name(), "num_threads": torch.get_num_threads(),
                        "num_interop_threads": torch.get_num_interop_threads(), "affinity": affinity},
        "notes": {
            "pairs": "Each round measures every backend once in randomized order, using identical fixed inputs; every round retained",
            "blocks": "Short blocks of10 calls by default, with synchronization at both ends; no profiler",
            "precision": "FP16 decoder uses FP32 computation plus input/output casts for every backend; tiny_host is FP32",
            "graph": "Shared input tensors and one captured graph per backend; repeated paired replay rounds each epoch",
            "process_cpu_time": "Diagnostic across all process threads; includes runtime synchronization and is not pure Python overhead",
            "pinning": "Two least-busy allowed physical cores selected from a250ms /proc/stat sample; masks applied to all existing threads and inherited by later workers",
            "comparability": "Controlled confirmation workload; absolute wall times may differ from unpinned prior run",
        },
        "cpu_scheduling_start": probe.cpu_scheduling(), "setup_errors": {}, "cases": [],
    }
    (args.output_dir / "proc-stat-start.txt").write_text(proc_stat()[0])
    report["clocks_start"] = clocks(affinity["selected"])

    def save():
        destination = args.output_dir / "confirmation.json"
        temporary = destination.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(report, indent=2) + "\n")
        temporary.replace(destination)

    try:
        selected = ["canonical", "canonical_before", "native_control", "hf"]
        load_args = argparse.Namespace(variants_dir=None, skip_hf=False, backends=selected)
        backends = probe_candidate.load_backends(load_args, report)
        if set(backends) != set(selected):
            raise RuntimeError("Not all requested backends loaded")
        for case_name, dtype in (("decoder", torch.float16), ("tiny_host", torch.float32)):
            data, grad, sizes, scale = probe.inputs(case_name, dtype)
            truth = probe.oracle(data, grad, sizes)
            case = {"case": case_name, "dtype": str(dtype), "correctness": {}, "graph_correctness": {},
                    "qualified_backends": [], "paired_rounds": [], "graph_rounds": [],
                    "epochs_completed": 0, "epoch_metadata": [],
                    "clocks_start": clocks(affinity["selected"])}
            report["cases"].append(case)
            runs, graphs = {}, {}
            for name, raw in backends.items():
                fn = raw if dtype == torch.float32 or name.startswith("canonical") else probe.common_precision(raw)
                case["correctness"][name] = probe.comparison(probe.evaluate(fn, data, grad), truth, dtype, scale)
                if not case["correctness"][name]["passed"]:
                    raise RuntimeError("FP64 qualification failed: " + name)
                runs[name] = probe.runner(fn, data, grad, "forward_backward")
                for _ in range(50):
                    runs[name]()
                torch.cuda.synchronize()
                graphs[name] = probe.capture(runs[name])
                case["graph_correctness"][name] = probe.comparison(graphs[name][1], truth, dtype, scale)
                if not case["graph_correctness"][name]["passed"]:
                    raise RuntimeError("Graph FP64 qualification failed: " + name)
                case["qualified_backends"].append(name)
            save()
            names = list(runs)
            for epoch in range(args.epochs):
                (args.output_dir / f"proc-stat-{case_name}-epoch{epoch}-before.txt").write_text(proc_stat()[0])
                begin = time.monotonic()
                while time.monotonic() - begin < args.seconds_per_case / args.epochs:
                    rng.shuffle(names)
                    row = {"epoch": epoch, "round": len(case["paired_rounds"]), "order": names.copy(), "backends": {}}
                    for name in names:
                        row["backends"][name] = block(runs[name], args.calls_per_block)
                    case["paired_rounds"].append(row)
                for _ in range(2):
                    rng.shuffle(names)
                    row = {"epoch": epoch, "round": len(case["graph_rounds"]), "order": names.copy(), "backends": {}}
                    for name in names:
                        measured = probe.measure_graph(graphs[name][0], samples=3, replays=30)
                        row["backends"][name] = {
                            "event_us": measured["event_ms_per_replay"]["median"] * 1000,
                            "wall_us": measured["wall_ms_per_replay"]["median"] * 1000,
                            "event_us_samples": [x * 1000 for x in measured["event_ms_per_replay"]["samples"]],
                            "wall_us_samples": [x * 1000 for x in measured["wall_ms_per_replay"]["samples"]],
                            "replays_per_sample": 30,
                        }
                    case["graph_rounds"].append(row)
                case["epochs_completed"] += 1
                case["epoch_metadata"].append({"epoch": epoch, "elapsed_seconds": time.monotonic() - begin,
                                               "clocks": clocks(affinity["selected"]),
                                               "cpu_scheduling": probe.cpu_scheduling()})
                (args.output_dir / f"proc-stat-{case_name}-epoch{epoch}-after.txt").write_text(proc_stat()[0])
                print(json.dumps({"case": case_name, "epoch": epoch, "paired_rounds": len(case["paired_rounds"])}), flush=True)
                save()
            case["summary"] = summarize_case(case)
            case["clocks_end"] = clocks(affinity["selected"])
            save()
            graphs.clear()
            del runs, data, grad, truth, scale
            gc.collect()
            torch.cuda.empty_cache()
        report["clocks_end"] = clocks(affinity["selected"])
        report["cpu_scheduling_end"] = probe.cpu_scheduling()
        (args.output_dir / "proc-stat-end.txt").write_text(proc_stat()[0])
        report["completed"] = True
        save()
        print(json.dumps({"completed": True, "output": str(args.output_dir / "confirmation.json")}), flush=True)
    except Exception:
        report["error"] = traceback.format_exc()
        save()
        raise


if __name__ == "__main__":
    main()
