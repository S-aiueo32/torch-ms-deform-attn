"""Fresh-process profiler with the isolated unchanged PR16 backend."""
import probe_candidate  # noqa: F401 - installs isolated-before backend loader
import one_case

if __name__ == '__main__':
    one_case.main()
