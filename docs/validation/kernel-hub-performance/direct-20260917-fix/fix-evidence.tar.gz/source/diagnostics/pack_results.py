"""Collect final validation/profiling evidence without build binaries or secrets."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/workspace/ci')
results = root / 'results'
profiles = []
for path in sorted(results.glob('profile-*/one-case.json')):
    data = json.loads(path.read_text())
    profiles.append({'source': str(path.relative_to(results)), **data})
assert len(profiles) == 6
assert all(p['completed'] and p['correctness']['passed'] and p['profile']['cuda_counts_complete'] for p in profiles)
(results / 'profiles.json').write_text(json.dumps(profiles, indent=2) + '\n')
for name in ('comparison', 'host-comparison'):
    data = json.loads((results / name / 'report.json').read_text())
    assert data['completed'] and not data['errors'] and not data['graph_errors'] and not data['setup_errors']
    assert all(x['passed'] for x in data['correctness'])
assert json.loads((results / 'cuda-tests.json').read_text())['success']
assert json.loads((results / 'fallback/report.json').read_text())['status'] == 'passed'
assert json.loads((results / 'adapter/adapter-check.json').read_text())['completed']

confirmation = json.loads((results / "confirmation/confirmation.json").read_text())
assert confirmation["completed"] and not confirmation.get("error")
assert all(all(v["passed"] for v in c["correctness"].values()) and all(v["passed"] for v in c["graph_correctness"].values()) for c in confirmation["cases"])

allowed = {'.json', '.txt', '.log', '.py', '.sh', '.h', '.cu', '.cuh', '.cpp', '.ninja', '.toml', '.pstats', '.patch', '.gz', '.md'}
files = []
for path in results.rglob('*'):
    if path.is_file() and path.suffix in allowed and path.name not in {'fix-evidence.tar.gz', 'evidence-manifest.json'}:
        files.append(path)
for path in (root / 'source/diagnostics').iterdir():
    if path.is_file() and path.suffix in allowed:
        files.append(path)
for name in ('vision.cpp', 'build.ninja', 'extension.json'):
    path = root / 'before/diagnostic-build' / name
    if path.is_file():
        files.append(path)
files = sorted(set(files))
manifest = {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
manifest_path = results / 'evidence-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
archive = results / 'fix-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as bundle:
    for path in files + [manifest_path]:
        bundle.add(path, arcname=str(path.relative_to(root)), recursive=False)
print(json.dumps({'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': len(files) + 1}))
