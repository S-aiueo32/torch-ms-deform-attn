"""Same-process public API comparison against the unchanged PR16 head."""
from before_loader import load_before
import probe

original_load_backends = probe.load_backends

def load_backends(args, report):
    backends = original_load_backends(args, report)
    before, native = load_before()
    report['before_binary'] = probe.fingerprint(native.__file__)
    report['before_revision'] = '2d604d2d9e2871ce2dc957278bbdae211e4b3fa8'
    if not args.backends or 'canonical_before' in args.backends:
        backends['canonical_before'] = before
    if args.backends and 'before_native' in args.backends:
        backends['before_native'] = probe.native_function(native.ms_deform_attn_forward, native.ms_deform_attn_backward)
    return backends

probe.load_backends = load_backends
probe.CASES['tiny_host'] = (1, 1, 1, 8, ((2, 2),))

if __name__ == '__main__':
    probe.main()
