#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
export PATH=/workspace/ci/profile-env/bin:$PATH
for msda_case in decoder encoder; do
  for msda_backend in canonical canonical_before hf; do
    python diagnostics/one_case_candidate.py --backend "$msda_backend" \
      --case "$msda_case" --mode forward_backward \
      --output-dir "/workspace/ci/results/profile-$msda_case-$msda_backend" \
      > "/workspace/ci/results/profile-$msda_case-$msda_backend.log" 2>&1
  done
done
python diagnostics/collect_binary.py /workspace/ci/results/comparison/report.json \
  --output-dir /workspace/ci/results/binary --backends canonical,canonical_before,hf --quiet
