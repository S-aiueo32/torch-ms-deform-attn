import torch
from . import _deformable_detr_cuda_5129df0
ops = torch.ops._deformable_detr_cuda_5129df0

def add_op_namespace_prefix(op_name: str):
    """
    Prefix op by namespace.
    """
    return f"_deformable_detr_cuda_5129df0::{op_name}"
