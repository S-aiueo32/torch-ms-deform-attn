from pathlib import Path
import base64
import datetime
import hashlib
import json

p = Path(__file__).resolve().parent
revision = "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"
snapshot = "8a6be7bc77565ad65c8ae2deb456482ff6aa50ed"
source_added = "158f270ed49815cc0f5ad4cf38478ea7f4521da3"
source_tree = {x["path"]: x for x in json.loads((p / "source-snapshot-tree.json").read_text())["tree"]}
hub_tree = {x["path"]: x for x in json.loads((p / "hub-tree.json").read_text())}
metadata = json.loads((p / "hub-build/metadata.json").read_text())
sigstore = json.loads((p / "hub-build/metadata.json.sigstore").read_text())
files = []
for folder in ("deformable_detr", "torch-ext"):
    for path in sorted((p / folder).rglob("*")):
        if not path.is_file():
            continue
        rel = str(path.relative_to(p))
        content = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        expected = source_tree["deformable-detr/" + rel]["sha"]
        assert blob == expected, rel
        files.append({"path": rel, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(),
                      "git_blob_sha1": blob, "matches_fixed_github_tree": True,
                      "url": f"https://raw.githubusercontent.com/huggingface/kernels-community/{snapshot}/deformable-detr/{rel}"})
hub_files = []
for path in sorted((p / "hub-build").rglob("*")):
    if not path.is_file():
        continue
    rel = str(path.relative_to(p / "hub-build"))
    content = path.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
    tree_path = "build/torch210-cxx11-cu126-x86_64-linux/" + rel
    assert blob == hub_tree[tree_path]["oid"], rel
    if rel in metadata["digest"]["files"]:
        assert hashlib.sha256(content).digest() == base64.b64decode(metadata["digest"]["files"][rel]), rel
    hub_files.append({"path": "hub-build/" + rel, "sha256": hashlib.sha256(content).hexdigest(),
                      "git_blob_sha1": blob, "matches_fixed_hub_tree": True})
binary = "_deformable_detr_cuda_5129df0.abi3.so"
binary_sha256 = base64.b64decode(metadata["digest"]["files"][binary]).hex()
assert binary_sha256 == "1a5053e022f3e5840ca9f40d361b5356ef0beeefdd8686029378dd4a7284b959"
assert hub_tree["build/torch210-cxx11-cu126-x86_64-linux/" + binary]["lfs"]["oid"] == binary_sha256
assert (p / "hub-build/__init__.py").read_bytes() == (p / "torch-ext/deformable_detr/__init__.py").read_bytes()
assert (p / "hub-build/layers.py").read_bytes() == (p / "torch-ext/deformable_detr/layers.py").read_bytes()
assert len(json.loads((p / "source-history.json").read_text())) == 1
assert len(json.loads((p / "wrapper-history.json").read_text())) == 1
(p / "metadata-signing-certificate.der").write_bytes(base64.b64decode(sigstore["verificationMaterial"]["certificate"]["rawBytes"]))
record = {
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hub_repository": "kernels-community/deformable-detr", "hub_repo_type": "kernel", "hub_revision": revision,
    "hub_build": "torch210-cxx11-cu126-x86_64-linux", "binary_file": binary, "binary_sha256": binary_sha256,
    "source_repository": "https://github.com/huggingface/kernels-community", "source_subdirectory": "deformable-detr",
    "source_snapshot_commit": snapshot, "cuda_and_wrapper_last_change_commit": source_added,
    "source_license": "Apache-2.0", "license_evidence": ["CUDA file copyright/license headers", "build.toml general.license", "hub-build/metadata.json license"],
    "license_note": "No standalone LICENSE file is present in the upstream repository snapshot; original per-file copyright headers are preserved.",
    "binding_sources": ["deformable_detr/ms_deform_attn_cuda.cu"], "include_path": ".", "declarations": "torch-ext/torch_binding.h",
    "forward_symbol": "ms_deform_attn_cuda_forward", "backward_symbol": "ms_deform_attn_cuda_backward", "im2col_step_type": "int64_t",
    "relationship_evidence": {
        "hub_metadata_and_lfs_match_previously_profiled_binary_sha256": True,
        "github_cuda_and_wrapper_history_only_initial_addition": True,
        "hub_public_python_init_byte_identical_to_github_source": True,
        "hub_layers_byte_identical_to_github_source": True,
        "downloaded_source_blobs_match_fixed_github_tree": True,
        "hub_binary_metadata_contains_original_build_source_commit": False,
        "sigstore_caveat": "Certificate identifies Sign old builds workflow at source_snapshot_commit. This is a later metadata-signing commit, NOT an attestation of the binary's original build source commit. Signature bundle is preserved, not cryptographically reverified here.",
        "conclusion": "Unmodified official CUDA source, unchanged in repository history, with byte-identical packaged Python implementation. Exact binary-to-original-build-commit provenance is not provided by this older artifact metadata."
    },
    "wrapper_semantics": {
        "function": "torch.autograd.Function with save_for_backward of all 5 input tensors and once_differentiable backward",
        "casting": "No input casts in the source wrapper; benchmark must enforce its common FP16-to-FP32 compute policy externally.",
        "contiguity": "No Python grad_output.contiguous(); CUDA host wrapper requires contiguous inputs and grad_output.",
        "module_forward": "Delegates to Function.apply; accepts but does not use value_spatial_shapes_list.",
        "operations": "Python public forward/backward simply delegate to generated torch.ops namespace."
    },
    "source_files": files, "hub_files": hub_files,
}
(p / "provenance.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"provenance": str(p / "provenance.json"), "source_files": len(files), "hub_files": len(hub_files), "binary_sha256": binary_sha256}, indent=2))
