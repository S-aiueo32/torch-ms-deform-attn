# PR #16 CUDA profiling summary

GPU: NVIDIA L4; PyTorch: 2.10.0+cu126; CUDA: 12.6.

Status: complete.
Wall and graph times are microseconds. Values are medians of repeat medians; ratios above 1 are slower than the named reference. Baseline reference: `candidate_rebuilt`.

Graph timing largely removes Python/dispatcher enqueue overhead, but includes GPU casts, allocations captured as operations, fills and kernels. Wall minus graph is not a direct measurement of host overhead.

HF exact requested revision loaded: `True`; loader arguments: `{"revision": "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"}`.

## decoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 89.40 [88.44, 89.82] | 48.56 | 1.000 | 1.000 | 1.187 | 0.919 |
| canonical | 7 | 65.31 [64.91, 65.99] | 55.40 | 0.731 | 1.141 | 0.867 | 1.048 |
| native_control | 7 | 75.84 [74.66, 75.98] | 52.87 | 0.848 | 1.089 | 1.007 | 1.000 |
| candidate_rebuilt | 7 | 75.31 [74.74, 76.06] | 52.87 | 0.842 | 1.089 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 75.58 [74.64, 76.32] | 51.26 | 0.845 | 1.055 | 1.004 | 0.969 |
| hf_rebuilt | 7 | 81.77 [80.63, 82.14] | 49.73 | 0.915 | 1.024 | 1.086 | 0.941 |

## decoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 361.04 [321.79, 372.72] | 158.50 | 1.000 | 1.000 | 1.242 | 0.933 |
| canonical | 7 | 293.50 [281.13, 331.98] | 173.12 | 0.813 | 1.092 | 1.010 | 1.020 |
| native_control | 7 | 308.83 [288.20, 339.77] | 168.46 | 0.855 | 1.063 | 1.062 | 0.992 |
| candidate_rebuilt | 7 | 290.70 [288.65, 322.91] | 169.80 | 0.805 | 1.071 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 291.29 [287.65, 346.29] | 172.39 | 0.807 | 1.088 | 1.002 | 1.015 |
| hf_rebuilt | 7 | 300.70 [297.55, 330.09] | 172.59 | 0.833 | 1.089 | 1.034 | 1.016 |

## decoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 46.55 [43.98, 49.39] | 30.79 | 1.000 | 1.000 | 1.200 | 0.869 |
| canonical | 7 | 38.60 [38.36, 38.93] | 35.44 | 0.829 | 1.151 | 0.995 | 1.000 |
| native_control | 7 | 38.81 [38.66, 39.12] | 35.42 | 0.834 | 1.150 | 1.001 | 1.000 |
| candidate_rebuilt | 7 | 38.79 [38.68, 39.15] | 35.43 | 0.833 | 1.151 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 37.71 [37.44, 37.92] | 34.16 | 0.810 | 1.109 | 0.972 | 0.964 |
| hf_rebuilt | 7 | 38.45 [38.14, 42.75] | 32.47 | 0.826 | 1.055 | 0.991 | 0.917 |

## decoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 232.11 [203.24, 246.46] | 126.88 | 1.000 | 1.000 | 1.200 | 0.960 |
| canonical | 7 | 170.14 [164.70, 203.02] | 141.53 | 0.733 | 1.115 | 0.879 | 1.071 |
| native_control | 7 | 174.84 [171.26, 207.87] | 139.67 | 0.753 | 1.101 | 0.904 | 1.056 |
| candidate_rebuilt | 7 | 193.46 [168.24, 211.95] | 132.20 | 0.833 | 1.042 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 174.41 [167.92, 211.32] | 138.02 | 0.751 | 1.088 | 0.902 | 1.044 |
| hf_rebuilt | 7 | 204.92 [182.95, 223.67] | 131.14 | 0.883 | 1.034 | 1.059 | 0.992 |

## encoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 697.08 [696.70, 698.33] | 688.69 | 1.000 | 1.000 | 0.958 | 0.958 |
| canonical | 7 | 731.89 [728.02, 734.22] | 725.87 | 1.050 | 1.054 | 1.005 | 1.009 |
| native_control | 7 | 727.40 [727.01, 733.58] | 719.36 | 1.043 | 1.045 | 0.999 | 1.000 |
| candidate_rebuilt | 7 | 727.90 [727.02, 734.17] | 719.26 | 1.044 | 1.044 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 712.83 [712.37, 716.52] | 715.21 | 1.023 | 1.039 | 0.979 | 0.994 |
| hf_rebuilt | 7 | 696.65 [694.33, 698.29] | 689.59 | 0.999 | 1.001 | 0.957 | 0.959 |

## encoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 2860.64 [2860.23, 2870.00] | 2951.11 | 1.000 | 1.000 | 0.978 | 0.985 |
| canonical | 7 | 2926.62 [2923.94, 2948.31] | 2983.03 | 1.023 | 1.011 | 1.000 | 0.996 |
| native_control | 7 | 2923.85 [2923.25, 2949.70] | 3001.45 | 1.022 | 1.017 | 0.999 | 1.002 |
| candidate_rebuilt | 7 | 2925.65 [2923.53, 2948.25] | 2994.72 | 1.023 | 1.015 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 2909.43 [2886.19, 2910.53] | 2948.04 | 1.017 | 0.999 | 0.994 | 0.984 |
| hf_rebuilt | 7 | 2860.71 [2858.00, 2884.27] | 2951.19 | 1.000 | 1.000 | 0.978 | 0.985 |

## encoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 571.99 [571.86, 573.45] | 566.98 | 1.000 | 1.000 | 0.949 | 0.946 |
| canonical | 7 | 602.64 [602.01, 603.62] | 599.48 | 1.054 | 1.057 | 1.000 | 1.000 |
| native_control | 7 | 602.17 [597.32, 602.98] | 598.78 | 1.053 | 1.056 | 0.999 | 0.999 |
| candidate_rebuilt | 7 | 602.77 [602.20, 603.38] | 599.42 | 1.054 | 1.057 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 582.04 [581.71, 586.90] | 577.21 | 1.018 | 1.018 | 0.966 | 0.963 |
| hf_rebuilt | 7 | 571.46 [571.28, 572.42] | 566.87 | 0.999 | 1.000 | 0.948 | 0.946 |

## encoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 2755.47 [2745.27, 2773.14] | 2823.26 | 1.000 | 1.000 | 0.988 | 0.987 |
| canonical | 7 | 2771.08 [2767.35, 2778.93] | 2855.67 | 1.006 | 1.011 | 0.994 | 0.998 |
| native_control | 7 | 2775.77 [2762.09, 2790.30] | 2857.14 | 1.007 | 1.012 | 0.996 | 0.998 |
| candidate_rebuilt | 7 | 2787.59 [2763.36, 2788.48] | 2861.79 | 1.012 | 1.014 | 1.000 | 1.000 |
| candidate_unchecked | 7 | 2733.10 [2724.03, 2753.23] | 2818.49 | 0.992 | 0.998 | 0.980 | 0.985 |
| hf_rebuilt | 7 | 2753.21 [2749.02, 2754.58] | 2812.21 | 0.999 | 0.996 | 0.988 | 0.983 |

Build logs not found for: hf_rebuilt, candidate_rebuilt, candidate_unchecked.

Correctness: 24/24 backend/case/dtype qualifications passed.
