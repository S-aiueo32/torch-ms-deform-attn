# Exact-binary CUDA inspection

Static SASS instruction counts describe the compiled instruction listing, not executed instructions, dynamic spill traffic, or elapsed-time attribution. Loops, branch paths and predication change runtime counts.

Register and local-memory sizes are compiled resource declarations. LDL/STL indicate local-memory instructions; local memory can have purposes besides spills.

Requested architecture: `sm_89`. Only that architecture is included in the comparison table.

| Backend | Kernel | Architecture | Registers | Stack bytes | Local bytes | Static inst. | Integer | IADD3 | IMAD | IMAD.WIDE | LDL | STL |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| hf | fwd, template index=absent | sm_89 | 39 | 0 | 0 | 240 | 148 | 26 | 70 | 5 | 0 | 0 |
| hf | bwd, C=32 | sm_89 | 47 | 0 | 0 | 432 | 148 | 62 | 34 | 7 | 0 | 0 |
| hf_rebuilt | fwd, template index=absent | sm_89 | 39 | 0 | 0 | 240 | 148 | 26 | 70 | 5 | 0 | 0 |
| hf_rebuilt | bwd, C=32 | sm_89 | 47 | 0 | 0 | 432 | 148 | 62 | 34 | 7 | 0 | 0 |
| candidate_rebuilt | fwd, template index=int | sm_89 | 42 | 0 | 0 | 304 | 205 | 39 | 99 | 9 | 0 | 0 |
| candidate_rebuilt | fwd, template index=long | sm_89 | 55 | 0 | 0 | 616 | 414 | 90 | 195 | 26 | 0 | 0 |
| candidate_rebuilt | bwd, C=32 | sm_89 | 70 | 0 | 0 | 472 | 174 | 66 | 49 | 8 | 0 | 0 |
| candidate_rebuilt | bwd, C=32 | sm_89 | 74 | 0 | 0 | 624 | 293 | 97 | 111 | 17 | 0 | 0 |
| candidate_unchecked | fwd, template index=int | sm_89 | 41 | 0 | 0 | 232 | 151 | 26 | 77 | 5 | 0 | 0 |
| candidate_unchecked | fwd, template index=long | sm_89 | 54 | 0 | 0 | 544 | 363 | 71 | 179 | 23 | 0 | 0 |
| candidate_unchecked | bwd, C=32 | sm_89 | 68 | 0 | 0 | 432 | 147 | 63 | 32 | 7 | 0 | 0 |
| candidate_unchecked | bwd, C=32 | sm_89 | 74 | 0 | 0 | 584 | 261 | 89 | 94 | 16 | 0 | 0 |
| candidate_unchecked_nobounds | fwd, template index=int | sm_89 | 39 | 0 | 0 | 240 | 148 | 26 | 70 | 5 | 0 | 0 |
| candidate_unchecked_nobounds | fwd, template index=long | sm_89 | 48 | 0 | 0 | 552 | 364 | 79 | 171 | 21 | 0 | 0 |
| candidate_unchecked_nobounds | bwd, C=32 | sm_89 | 68 | 0 | 0 | 432 | 147 | 63 | 32 | 7 | 0 | 0 |
| candidate_unchecked_nobounds | bwd, C=32 | sm_89 | 74 | 0 | 0 | 584 | 261 | 89 | 94 | 16 | 0 | 0 |
| candidate_unchecked_hfloop | fwd, template index=int | sm_89 | 41 | 0 | 0 | 232 | 151 | 26 | 77 | 5 | 0 | 0 |
| candidate_unchecked_hfloop | fwd, template index=long | sm_89 | 55 | 0 | 0 | 544 | 359 | 71 | 173 | 21 | 0 | 0 |
| candidate_unchecked_hfloop | bwd, C=32 | sm_89 | 68 | 0 | 0 | 432 | 147 | 63 | 32 | 7 | 0 | 0 |
| candidate_unchecked_hfloop | bwd, C=32 | sm_89 | 74 | 0 | 0 | 584 | 265 | 92 | 95 | 15 | 0 | 0 |
| hf_empty | fwd, template index=absent | sm_89 | 39 | 0 | 0 | 240 | 148 | 26 | 70 | 5 | 0 | 0 |
| hf_empty | bwd, C=32 | sm_89 | 47 | 0 | 0 | 432 | 148 | 62 | 34 | 7 | 0 | 0 |

## Binary provenance

- `hf`: `/home/ci/.cache/huggingface/hub/blobs/7d/7d2a02fde1afb32bee02103a78562d1d7e71a0be3ac3b0f1848c5303d8c89a79`; SHA256 `1a5053e022f3e5840ca9f40d361b5356ef0beeefdd8686029378dd4a7284b959`; measured-report hash match: `True`.
- `hf_rebuilt`: `/workspace/ci/results/rebuilt/hf_rebuilt/build/_msda_hf_rebuilt.so`; SHA256 `0e7bd2fa503cccca7940643929aa180e051a4c5edc3cd5a670c16491f8ae7805`; measured-report hash match: `True`.
- `candidate_rebuilt`: `/workspace/ci/results/rebuilt/candidate_rebuilt/build/_msda_candidate_rebuilt.so`; SHA256 `9895b7f7c1ccd167035bfc90e98c6aef90db2fc62eef3d98e9800a69350f6a7b`; measured-report hash match: `True`.
- `candidate_unchecked`: `/workspace/ci/results/rebuilt/candidate_unchecked/build/_msda_candidate_unchecked.so`; SHA256 `a5938d0282afa8a372485eb6b884fe6776ab0c7e3f4d380a316f32c5a0ac0dbc`; measured-report hash match: `True`.
- `candidate_unchecked_nobounds`: `/workspace/ci/results/followup/candidate_unchecked_nobounds/build/_msda_candidate_unchecked_nobounds.so`; SHA256 `bd086e9ab389a7eec6ade3124542db1631ea6f0a2f3794c8d663cf72edd1ed20`; measured-report hash match: `True`.
- `candidate_unchecked_hfloop`: `/workspace/ci/results/followup/candidate_unchecked_hfloop/build/_msda_candidate_unchecked_hfloop.so`; SHA256 `2a3a5021f25dd5aa68239274fa0fef5c20c443c0f25319f4aeacf44faad8e422`; measured-report hash match: `True`.
- `hf_empty`: `/workspace/ci/results/followup/hf_empty/build/_msda_hf_empty.so`; SHA256 `c7bf79ffd659ccf44431de8c10cfcd353a37baa81ad46c027595c7e84d199fb1`; measured-report hash match: `True`.
