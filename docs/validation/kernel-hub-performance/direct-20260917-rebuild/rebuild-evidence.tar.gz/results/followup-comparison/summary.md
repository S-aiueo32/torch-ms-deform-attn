# PR #16 CUDA profiling summary

GPU: NVIDIA L4; PyTorch: 2.10.0+cu126; CUDA: 12.6.

Status: complete.
Wall and graph times are microseconds. Values are medians of repeat medians; ratios above 1 are slower than the named reference. Baseline reference: `candidate_unchecked`.

Graph timing largely removes Python/dispatcher enqueue overhead, but includes GPU casts, allocations captured as operations, fills and kernels. Wall minus graph is not a direct measurement of host overhead.

HF exact requested revision loaded: `True`; loader arguments: `{"revision": "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"}`.

## encoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 704.88 [699.48, 711.97] | 696.42 | 1.000 | 1.000 | 0.977 | 0.983 |
| candidate_rebuilt | 7 | 738.70 [731.76, 746.96] | 727.07 | 1.048 | 1.044 | 1.024 | 1.026 |
| candidate_unchecked | 7 | 721.70 [717.58, 724.59] | 708.53 | 1.024 | 1.017 | 1.000 | 1.000 |
| candidate_unchecked_hfloop | 7 | 723.86 [715.63, 730.25] | 704.65 | 1.027 | 1.012 | 1.003 | 0.995 |
| candidate_unchecked_nobounds | 7 | 700.11 [697.17, 708.37] | 689.40 | 0.993 | 0.990 | 0.970 | 0.973 |
| hf_empty | 7 | 700.20 [690.84, 701.94] | 678.66 | 0.993 | 0.975 | 0.970 | 0.958 |
| hf_rebuilt | 7 | 709.92 [704.36, 711.71] | 701.25 | 1.007 | 1.007 | 0.984 | 0.990 |

## encoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 572.33 [570.26, 577.79] | 567.04 | 1.000 | 1.000 | 0.985 | 0.972 |
| candidate_rebuilt | 7 | 598.03 [596.29, 605.20] | 599.14 | 1.045 | 1.057 | 1.029 | 1.028 |
| candidate_unchecked | 7 | 581.15 [573.98, 587.64] | 583.09 | 1.015 | 1.028 | 1.000 | 1.000 |
| candidate_unchecked_hfloop | 7 | 581.48 [581.08, 587.61] | 582.38 | 1.016 | 1.027 | 1.001 | 0.999 |
| candidate_unchecked_nobounds | 7 | 563.61 [557.71, 568.86] | 561.87 | 0.985 | 0.991 | 0.970 | 0.964 |
| hf_empty | 7 | 563.12 [558.36, 564.09] | 559.90 | 0.984 | 0.987 | 0.969 | 0.960 |
| hf_rebuilt | 7 | 571.75 [570.03, 577.21] | 567.26 | 0.999 | 1.000 | 0.984 | 0.973 |

Build logs not found for: hf_rebuilt, candidate_rebuilt, candidate_unchecked, candidate_unchecked_nobounds, candidate_unchecked_hfloop, hf_empty.

Correctness: 14/14 backend/case/dtype qualifications passed.
