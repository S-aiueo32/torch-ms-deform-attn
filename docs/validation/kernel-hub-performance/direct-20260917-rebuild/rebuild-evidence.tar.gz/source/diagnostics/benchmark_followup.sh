#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
export PATH=/workspace/ci/profile-env/bin:$PATH
python diagnostics/combine_manifests.py
python diagnostics/probe.py --variants-dir /workspace/ci/results/combined \
  --output-dir /workspace/ci/results/followup-comparison \
  --cases encoder --dtypes float32 float16 --modes forward \
  --backends hf hf_rebuilt candidate_rebuilt candidate_unchecked \
    candidate_unchecked_nobounds candidate_unchecked_hfloop hf_empty \
  --repeats 7 --min-run-time 0.6 --skip-profile \
  > /workspace/ci/results/followup-comparison.log 2>&1
python diagnostics/summarize.py /workspace/ci/results/followup-comparison/report.json \
  --baseline candidate_unchecked --quiet
for msda_backend in candidate_unchecked_nobounds candidate_unchecked_hfloop hf_empty; do
  python diagnostics/one_case.py --variants-dir /workspace/ci/results/combined \
    --backend "$msda_backend" --case encoder --dtype float32 --mode forward \
    --output-dir "/workspace/ci/results/followup-profile-$msda_backend" \
    > "/workspace/ci/results/followup-profile-$msda_backend.log" 2>&1
done
python diagnostics/collect_binary.py /workspace/ci/results/followup-comparison/report.json \
  --variants-dir /workspace/ci/results/combined --output-dir /workspace/ci/results/followup-binary \
  --backends hf,hf_rebuilt,candidate_rebuilt,candidate_unchecked,candidate_unchecked_nobounds,candidate_unchecked_hfloop,hf_empty --quiet
echo 'FOLLOWUP COMPLETE'
