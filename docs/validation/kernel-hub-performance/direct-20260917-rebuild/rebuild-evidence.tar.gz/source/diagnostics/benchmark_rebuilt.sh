#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
export PATH=/workspace/ci/profile-env/bin:$PATH
export CUDA_HOME=/usr/local/cuda TORCH_CUDA_ARCH_LIST=8.9 MAX_JOBS=2
python diagnostics/probe.py --variants-dir /workspace/ci/results/rebuilt \
  --output-dir /workspace/ci/results/comparison \
  --cases decoder encoder --dtypes float32 float16 \
  --backends canonical native_control hf hf_rebuilt candidate_rebuilt candidate_unchecked \
  --repeats 7 --min-run-time 0.6 --skip-profile \
  > /workspace/ci/results/comparison.log 2>&1
python diagnostics/summarize.py /workspace/ci/results/comparison/report.json \
  --baseline candidate_rebuilt --quiet
echo 'COMPARISON COMPLETE'
