#!/usr/bin/env python3
"""Prepare/build independent diagnostic controls after the matched rebuild.

Each candidate control changes one additional factor relative to
candidate_unchecked. hf_empty changes one factor relative to hf_rebuilt.
The original rebuilt manifest and source directories are never modified.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import traceback

import build_rebuilt as base


VARIANTS = ("candidate_unchecked_nobounds", "candidate_unchecked_hfloop", "hf_empty")
CANDIDATE_HEADER = "csrc/cuda/ms_deform_im2col_cuda.cuh"
HF_HEADER = "deformable_detr/ms_deform_im2col_cuda.cuh"


def digest_text(text):
    return hashlib.sha256(text.encode()).hexdigest()


def kernel_loop_macro(text):
    lines = text.splitlines(keepends=True)
    starts = [index for index, line in enumerate(lines) if line.startswith("#define CUDA_KERNEL_LOOP(")]
    if len(starts) != 1:
        raise RuntimeError(f"Expected one CUDA_KERNEL_LOOP macro, found {len(starts)}")
    start = starts[0]
    end = start + 1
    while lines[end - 1].rstrip().endswith("\\"):
        end += 1
    return "".join(lines[start:end])


def mutate(entry, relative, transform, description, **details):
    path = Path(entry["copied_sources_before_build"][relative]["path"])
    before = path.read_text()
    after = transform(before)
    if before == after:
        raise RuntimeError(f"No source change for {description}")
    path.write_text(after)
    entry["mutations"].append({
        "file": relative,
        "change": description,
        "before_sha256": digest_text(before),
        "after_sha256": digest_text(after),
        "floating_point_expressions_changed": False,
        **details,
    })
    entry["copied_sources_before_build"][relative] = base.fingerprint(path)


def replace_exact(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError(f"Expected one source fragment, found {text.count(old)}: {old!r}")
    return text.replace(old, new, 1)


def unchecked(text):
    pattern = r"(__device__ inline bool valid_spatial_level\([^)]*\)\s*\{).*?\n\}"
    result, count = re.subn(
        pattern,
        r"\1\n  // Diagnostic only: inputs are prevalidated by probe.py.\n  return true;\n}",
        text,
        flags=re.S,
    )
    if count != 1:
        raise RuntimeError(f"Expected one metadata helper, found {count}")
    return result


def prepare_one(name, args, baseline):
    if name == "hf_empty":
        parent = "hf_rebuilt"
        entry = base.prepare(name, args.hf_root, Path("deformable_detr"),
                             Path("deformable_detr/ms_deform_attn_cuda.cu"), args.output_dir, "int64_t")
        target = "deformable_detr/ms_deform_attn_cuda.cu"
        mutate(
            entry, target,
            lambda text: replace_exact(text, "auto output = at::zeros(", "auto output = at::empty("),
            "Replace only forward output allocation at::zeros with at::empty",
            backward_zero_initialization_preserved=True,
        )
    else:
        parent = "candidate_unchecked"
        entry = base.prepare(name, args.candidate_root, Path("csrc/cuda"),
                             Path("csrc/cuda/ms_deform_attn_cuda.cu"), args.output_dir, "int")
        mutate(entry, CANDIDATE_HEADER, unchecked,
               "Baseline candidate_unchecked: replace only valid_spatial_level body with return true")
        entry["unchecked_baseline_source_sha256"] = {
            key: item["sha256"] for key, item in entry["copied_sources_before_build"].items()
        }
        if name == "candidate_unchecked_nobounds":
            old = "__global__ void __launch_bounds__(CUDA_NUM_THREADS)\n    ms_deformable_im2col_gpu_kernel"
            new = "__global__ void\n    ms_deformable_im2col_gpu_kernel"
            mutate(entry, CANDIDATE_HEADER, lambda text: replace_exact(text, old, new),
                   "Remove forward launch bound only; retain all backward launch bounds and block sizes",
                   kernels_affected=["ms_deformable_im2col_gpu_kernel"])
        elif name == "candidate_unchecked_hfloop":
            hf_macro = kernel_loop_macro((args.hf_root / HF_HEADER).read_text())
            mutate(entry, CANDIDATE_HEADER,
                   lambda text: replace_exact(text, kernel_loop_macro(text), hf_macro),
                   "Replace CUDA_KERNEL_LOOP definition byte-for-byte with the HF source macro",
                   kernels_affected="All CUDA_KERNEL_LOOP users: forward and all backward families",
                   macro_source=base.fingerprint(args.hf_root / HF_HEADER),
                   replacement_macro=hf_macro,
                   large_index_fallback_is_unsafe=True)
        entry["unvalidated_metadata_is_unsafe"] = True
    entry["independent_comparison_baseline"] = parent
    entry["additional_factors_vs_baseline"] = 1
    entry["changed_source_files"] = [
        key for key in entry["original_sources"]
        if entry["original_sources"][key]["sha256"] != entry["copied_sources_before_build"][key]["sha256"]
    ]
    if len(entry["changed_source_files"]) != 1:
        raise RuntimeError("Each followup must alter exactly one source file")
    if baseline:
        parents = {item["name"]: item for item in baseline["variants"]}
        reference = parents[parent]
        for key, original in entry["original_sources"].items():
            if original["sha256"] != reference["original_sources"][key]["sha256"]:
                raise RuntimeError(f"Original source differs from prior measured build: {key}")
        if parent == "candidate_unchecked":
            for key, digest in entry["unchecked_baseline_source_sha256"].items():
                if digest != reference["copied_sources_before_build"][key]["sha256"]:
                    raise RuntimeError(f"Unchecked starting point differs from prior build: {key}")
        entry["baseline_binary_sha256"] = reference.get("binary_sha256")
    return entry


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hf-root", type=Path, default=Path("/workspace/ci/hf-source"))
    parser.add_argument("--candidate-root", type=Path, default=Path("/workspace/ci/source"))
    parser.add_argument("--output-dir", type=Path, default=Path("/workspace/ci/results/followup"))
    parser.add_argument("--baseline-manifest", type=Path, default=Path("/workspace/ci/results/rebuilt/manifest.json"))
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--variants", nargs="+", choices=VARIANTS, default=VARIANTS)
    args = parser.parse_args()
    for name in ("hf_root", "candidate_root", "output_dir", "baseline_manifest"):
        setattr(args, name, getattr(args, name).resolve())
    if args.output_dir == args.baseline_manifest.parent:
        raise RuntimeError("Followup output must not overwrite the original rebuilt manifest")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MAX_JOBS", "2")
    baseline = json.loads(args.baseline_manifest.read_text())
    manifest = {
        "description": __doc__,
        "baseline_manifest": base.fingerprint(args.baseline_manifest),
        "builder": base.fingerprint(Path(base.__file__)),
        "followup_builder": base.fingerprint(Path(__file__)),
        "qualification": "Only fixed valid contiguous probe.py inputs below INT32_MAX/2; FP64 oracle gates output/all3 gradients before timing",
        "environment": {key: os.environ.get(key) for key in (
            "CXX", "CC", "CUDA_HOME", "CUDAHOSTCXX", "NVCC_CCBIN", "TORCH_CUDA_ARCH_LIST",
            "MAX_JOBS", "NVCC_PREPEND_FLAGS", "NVCC_APPEND_FLAGS",
        )},
        "variants": [],
    }
    try:
        manifest["variants"] = [prepare_one(name, args, baseline) for name in args.variants]
        base.save(args.output_dir / "manifest.json", manifest)
        if args.prepare_only:
            print(json.dumps({"status": "prepared", "variants": list(args.variants), "output": str(args.output_dir)}))
            return 0
        import torch
        from torch.utils.cpp_extension import CUDA_HOME, get_cxx_compiler

        cxx = shlex.split(get_cxx_compiler())
        nvcc = str(Path(CUDA_HOME) / "bin/nvcc")
        manifest["toolchain"] = {
            "torch": torch.__version__, "torch_cuda": torch.version.cuda,
            "cxx_version": base.command_output(cxx + ["--version"]),
            "nvcc_version": base.command_output([nvcc, "--version"]),
            "nvcc_binary": base.fingerprint(nvcc),
            "cxx_binary": base.fingerprint(shutil.which(cxx[0])),
            "gpu": torch.cuda.get_device_name(), "capability": torch.cuda.get_device_capability(),
        }
        for entry in manifest["variants"]:
            entry["status"] = "building"
            base.save(args.output_dir / "manifest.json", manifest)
            base.build_one(entry)
            base.save(args.output_dir / "manifest.json", manifest)
            print(json.dumps({"status": "built", "variant": entry["name"], "binary": entry["artifact"]}), flush=True)
        if base.fingerprint(args.baseline_manifest)["sha256"] != manifest["baseline_manifest"]["sha256"]:
            raise RuntimeError("Original rebuilt manifest changed during followup")
        manifest["completed"] = True
        base.save(args.output_dir / "manifest.json", manifest)
        return 0
    except Exception:
        manifest["error"] = traceback.format_exc()
        base.save(args.output_dir / "manifest.json", manifest)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
