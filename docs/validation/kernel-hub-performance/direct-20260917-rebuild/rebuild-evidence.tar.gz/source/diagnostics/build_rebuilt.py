#!/usr/bin/env python3
"""Build HF and candidate CUDA with one compiler configuration and thin bindings.

This is a diagnostic builder. candidate_unchecked is qualified only on the
fixed, valid, range-checked inputs used by probe.py; it is not a product build.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import time
import traceback


BINDING = r"""
#include <ATen/ATen.h>
#include <torch/csrc/utils/pybind.h>
#include <pybind11/stl.h>

at::Tensor ms_deform_attn_cuda_forward(
    const at::Tensor &, const at::Tensor &, const at::Tensor &,
    const at::Tensor &, const at::Tensor &, const @STEP_TYPE@);
std::vector<at::Tensor> ms_deform_attn_cuda_backward(
    const at::Tensor &, const at::Tensor &, const at::Tensor &,
    const at::Tensor &, const at::Tensor &, const at::Tensor &, const @STEP_TYPE@);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
  module.def("forward", &ms_deform_attn_cuda_forward);
  module.def("backward", &ms_deform_attn_cuda_backward);
}
"""
SOURCE_SUFFIXES = {".h", ".hpp", ".cuh", ".cu", ".cpp"}


def fingerprint(path):
    path = Path(path)
    return {
        "path": str(path.resolve()),
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def command_output(command):
    completed = subprocess.run(command, capture_output=True, text=True, check=False)
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def prepare(name, original_root, source_subdir, cuda_relative, output, step_type):
    root = output / name
    copied = root / "source"
    copied.mkdir(parents=True, exist_ok=True)
    originals = {}
    copies = {}
    mutations = []
    for path in sorted((original_root / source_subdir).rglob("*")):
        if not path.is_file() or path.suffix not in SOURCE_SUFFIXES:
            continue
        relative = path.relative_to(original_root)
        destination = copied / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        originals[str(relative)] = fingerprint(path)
        if name == "candidate_unchecked" and path.name == "ms_deform_im2col_cuda.cuh":
            text = destination.read_text()
            pattern = r"(__device__ inline bool valid_spatial_level\([^)]*\)\s*\{).*?\n\}"
            text, count = re.subn(
                pattern,
                r"\1\n  // Diagnostic only: inputs are prevalidated by probe.py.\n  return true;\n}",
                text,
                flags=re.S,
            )
            if count != 1:
                raise RuntimeError(f"Expected one metadata helper, found {count}")
            destination.write_text(text)
            mutations.append({
                "file": str(relative),
                "change": "Replace only valid_spatial_level body with return true",
                "validation_removed": "Device metadata bounds calculation, assertion, and return guard become constant true",
                "floating_point_code_changed": False,
                "host_index_selection_changed": False,
            })
        copies[str(relative)] = fingerprint(destination)
    if not (copied / cuda_relative).is_file():
        raise FileNotFoundError(copied / cuda_relative)
    if name == "candidate_unchecked" and len(mutations) != 1:
        raise RuntimeError("Unchecked control did not modify exactly one helper")
    changed = [key for key in originals if originals[key]["sha256"] != copies[key]["sha256"]]
    if name != "candidate_unchecked" and changed:
        raise RuntimeError(f"Unmodified rebuild copied changed source: {changed}")
    binding = root / "binding.cpp"
    binding.write_text(BINDING.replace("@STEP_TYPE@", step_type))
    return {
        "name": name,
        "module_name": "_msda_" + name,
        "forward": "forward",
        "backward": "backward",
        "build_directory": str(root / "build"),
        "sources": [str(binding), str(copied / cuda_relative)],
        "include_paths": [str(copied), str(copied / "csrc")],
        "cxx_flags": ["-O3"],
        "cuda_flags": ["-O3"],
        "source_step_type": step_type,
        "original_sources": originals,
        "copied_sources_before_build": copies,
        "binding": fingerprint(binding),
        "changed_source_files": changed,
        "mutations": mutations,
        "unvalidated_metadata_is_unsafe": name == "candidate_unchecked",
        "status": "prepared",
    }


def build_one(entry):
    import torch
    from torch.utils.cpp_extension import load

    directory = Path(entry["build_directory"])
    directory.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    module = load(
        name=entry["module_name"],
        sources=entry["sources"],
        extra_include_paths=entry["include_paths"],
        extra_cflags=entry["cxx_flags"],
        extra_cuda_cflags=entry["cuda_flags"],
        build_directory=str(directory),
        with_cuda=True,
        verbose=True,
    )
    after = {key: fingerprint(item["path"]) for key, item in entry["copied_sources_before_build"].items()}
    for key, before in entry["copied_sources_before_build"].items():
        if before["sha256"] != after[key]["sha256"]:
            raise RuntimeError(f"CUDA source changed during compilation: {key}")
    artifact = fingerprint(module.__file__)
    ninja = directory / "build.ninja"
    entry.update(
        status="built",
        path=artifact["path"],
        artifact=artifact,
        binary_sha256=artifact["sha256"],
        build_seconds=time.monotonic() - started,
        copied_sources_after_build=after,
        build_ninja=fingerprint(ninja),
        ninja_commands=command_output(["ninja", "-C", str(directory), "-t", "commands"]),
        torch_version=torch.__version__,
        torch_cuda=torch.version.cuda,
    )
    # Preserve the actual command text next to the build manifest.
    (directory.parent / "ninja-commands.txt").write_text(entry["ninja_commands"]["stdout"])
    return entry


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hf-root", type=Path, default=Path("/workspace/ci/hf-source"))
    parser.add_argument("--candidate-root", type=Path, default=Path("/workspace/ci/source"))
    parser.add_argument("--output-dir", type=Path, default=Path("/workspace/ci/results/rebuilt"))
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--variants", nargs="+", choices=("hf_rebuilt", "candidate_rebuilt", "candidate_unchecked"),
                        default=("hf_rebuilt", "candidate_rebuilt", "candidate_unchecked"))
    args = parser.parse_args()
    hf_root, candidate_root, output = args.hf_root.resolve(), args.candidate_root.resolve(), args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MAX_JOBS", "2")
    manifest = {
        "description": "HF and candidate CUDA sources compiled by one JIT toolchain; no fast math or lineinfo flags",
        "hf_source_root": str(hf_root),
        "candidate_source_root": str(candidate_root),
        "hf_provenance_files": {},
        "environment": {key: os.environ.get(key) for key in (
            "CXX", "CC", "CUDA_HOME", "CUDAHOSTCXX", "NVCC_CCBIN", "TORCH_CUDA_ARCH_LIST",
            "MAX_JOBS", "NVCC_PREPEND_FLAGS", "NVCC_APPEND_FLAGS",
        )},
        "qualification": "probe.py prevalidates fixed metadata and every index span, then FP64-oracle output/all3-gradient checks before timing",
        "variants": [],
    }
    for path in sorted(hf_root.glob("*.json")):
        manifest["hf_provenance_files"][path.name] = {
            "fingerprint": fingerprint(path),
            "data": json.loads(path.read_text()),
        }
    try:
        for name in args.variants:
            if name == "hf_rebuilt":
                entry = prepare(name, hf_root, Path("deformable_detr"), Path("deformable_detr/ms_deform_attn_cuda.cu"), output, "int64_t")
            else:
                entry = prepare(name, candidate_root, Path("csrc/cuda"), Path("csrc/cuda/ms_deform_attn_cuda.cu"), output, "int")
            manifest["variants"].append(entry)
        save(output / "manifest.json", manifest)
        if args.prepare_only:
            print(json.dumps({"status": "prepared", "manifest": str(output / "manifest.json")}))
            return 0
        import torch
        from torch.utils.cpp_extension import CUDA_HOME, get_cxx_compiler

        cxx = shlex.split(get_cxx_compiler())
        nvcc = str(Path(CUDA_HOME) / "bin/nvcc")
        manifest["toolchain"] = {
            "torch": torch.__version__,
            "torch_cuda": torch.version.cuda,
            "cxx_version": command_output(cxx + ["--version"]),
            "nvcc_version": command_output([nvcc, "--version"]),
            "nvcc_binary": fingerprint(nvcc),
            "cxx_binary": fingerprint(shutil.which(cxx[0])),
            "gpu": torch.cuda.get_device_name(),
            "capability": torch.cuda.get_device_capability(),
        }
        for entry in manifest["variants"]:
            entry["status"] = "building"
            save(output / "manifest.json", manifest)
            build_one(entry)
            save(output / "manifest.json", manifest)
            print(json.dumps({"status": "built", "variant": entry["name"], "binary": entry["artifact"]}), flush=True)
        manifest["completed"] = True
        save(output / "manifest.json", manifest)
        return 0
    except Exception:
        manifest["error"] = traceback.format_exc()
        save(output / "manifest.json", manifest)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
