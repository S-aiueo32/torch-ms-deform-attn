"""Combine completed builds for loading, retaining the original manifests."""
import hashlib
import json
from pathlib import Path

results = Path('/workspace/ci/results')
original = results / 'rebuilt/manifest.json'
extra = results / 'followup/manifest.json'
main = json.loads(original.read_text())
followup = json.loads(extra.read_text())
assert main['completed'] and followup['completed']
assert main['toolchain']['nvcc_binary']['sha256'] == followup['toolchain']['nvcc_binary']['sha256']
assert main['toolchain']['cxx_binary']['sha256'] == followup['toolchain']['cxx_binary']['sha256']
combined = {
    'description': 'Unmodified references to both completed build manifests',
    'sources': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, extra)},
    'variants': main['variants'] + followup['variants'],
}
assert len({v['name'] for v in combined['variants']}) == 6
target = results / 'combined'
target.mkdir(exist_ok=True)
(target / 'manifest.json').write_text(json.dumps(combined, indent=2) + '\n')
