"""Require complete measurements and save source-bound evidence without binaries."""

import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/workspace/ci')
results = root / 'results'
data = json.loads((results / 'comparison/report.json').read_text())
assert data['completed'] and not data['setup_errors'] and not data['errors'] and not data['graph_errors']
assert len(data['correctness']) == 24 and all(x['passed'] for x in data['correctness'])
assert len(data['measurements']) == 336
assert data['hf']['exact_requested_revision_loaded']
profiles = [json.loads(p.read_text()) for p in sorted(results.glob('profile-*/one-case.json'))]
assert len(profiles) == 5
assert all(p['completed'] and p['correctness']['passed'] and p['profile']['cuda_counts_complete'] for p in profiles)
(results / 'profiles.json').write_text(json.dumps(profiles, indent=2) + '\n')
binary = json.loads((results / 'binary/binary_summary.json').read_text())
assert len(binary['binaries']) == 5 and not binary['missing_backends']
assert all(b['matches_report_sha256'] for b in binary['binaries'])
builds = json.loads((results / 'rebuilt/manifest.json').read_text())
assert builds['completed'] and all(v['status'] == 'built' for v in builds['variants'])
followup = json.loads((results / "followup-comparison/report.json").read_text())
assert followup["completed"] and not followup["setup_errors"] and not followup["errors"] and not followup["graph_errors"]
assert len(followup["correctness"]) == 14 and all(x["passed"] for x in followup["correctness"])
assert len(followup["measurements"]) == 98
more_profiles = [json.loads(p.read_text()) for p in sorted(results.glob("followup-profile-*/one-case.json"))]
assert len(more_profiles) == 3 and all(p["completed"] and p["correctness"]["passed"] and p["profile"]["cuda_counts_complete"] for p in more_profiles)
(results / "followup-profiles.json").write_text(json.dumps(more_profiles, indent=2) + "\n")
more_binary = json.loads((results / "followup-binary/binary_summary.json").read_text())
assert len(more_binary["binaries"]) == 7 and not more_binary["missing_backends"]
assert all(b["matches_report_sha256"] for b in more_binary["binaries"])

allowed = {'.json', '.txt', '.log', '.py', '.sh', '.h', '.cuh', '.cu', '.cpp', '.toml', '.nix', '.lock', '.ninja', '.patch', '.gz', '.md', '.der'}
files = []
for parent in (results, root / 'source/diagnostics', root / 'hf-source'):
    for p in parent.rglob('*'):
        if p.is_file() and p.suffix in allowed and p.name not in {'rebuild-evidence.tar.gz', 'evidence-manifest.json'}:
            files.append(p)
files = sorted(set(files))
manifest = {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
manifest_path = results / 'evidence-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
archive = results / 'rebuild-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as t:
    for p in files + [manifest_path]:
        t.add(p, arcname=str(p.relative_to(root)), recursive=False)
print(json.dumps({'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size, 'members': len(files) + 1}))
