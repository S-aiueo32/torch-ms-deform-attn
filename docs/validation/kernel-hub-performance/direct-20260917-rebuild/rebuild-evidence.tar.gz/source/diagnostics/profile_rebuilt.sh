#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
export PATH=/workspace/ci/profile-env/bin:$PATH
for msda_backend in canonical hf hf_rebuilt candidate_rebuilt candidate_unchecked; do
  python diagnostics/one_case.py --variants-dir /workspace/ci/results/rebuilt \
    --backend "$msda_backend" --case encoder --dtype float32 --mode forward \
    --output-dir "/workspace/ci/results/profile-$msda_backend" \
    > "/workspace/ci/results/profile-$msda_backend.log" 2>&1
done
python diagnostics/collect_binary.py /workspace/ci/results/comparison/report.json \
  --variants-dir /workspace/ci/results/rebuilt --output-dir /workspace/ci/results/binary \
  --backends canonical,hf,hf_rebuilt,candidate_rebuilt,candidate_unchecked --quiet
echo 'PROFILING COMPLETE'
