import torch
ops = getattr(torch.ops, 'msda_adapter_diagnostic')

def add_op_namespace_prefix(name):
    return 'msda_adapter_diagnostic::' + name
