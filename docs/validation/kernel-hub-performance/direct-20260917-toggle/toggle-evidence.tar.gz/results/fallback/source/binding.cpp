
#include <ATen/ATen.h>
#include <torch/csrc/utils/pybind.h>
#include <pybind11/stl.h>
#include "cuda/index_utils.h"

#include "cuda/ms_deform_attn_cuda.h"


PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
  module.def("forward", &ms_deform_attn_cuda_forward);
  module.def("backward", &ms_deform_attn_cuda_backward);
  module.def("check_indexing", &ms_deform_attn::check_cuda_indexing);
}
