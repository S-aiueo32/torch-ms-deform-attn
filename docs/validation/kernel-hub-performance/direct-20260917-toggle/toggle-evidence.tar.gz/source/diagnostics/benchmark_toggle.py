import hashlib
import json
import random
import statistics
from pathlib import Path

import torch
from torch_ms_deform_attn import _C, ms_deform_attn

torch.manual_seed(31)
stream = torch.cuda.Stream()
rows = []
with torch.cuda.stream(stream), torch.no_grad():
    shapes = torch.tensor([[64, 64], [32, 32], [16, 16], [8, 8]], device="cuda")
    starts = torch.tensor([0, 4096, 5120, 5376], device="cuda")
    for case, queries in (("decoder", 300), ("encoder", 5440)):
        value = torch.randn(2, 5440, 8, 32, device="cuda")
        loc = torch.rand(2, queries, 8, 4, 4, 2, device="cuda")
        weights = torch.rand(2, queries, 8, 4, 4, device="cuda")
        graphs = {}
        outputs = {}
        for check in (False, True):
            for _ in range(20):
                ms_deform_attn(value, shapes, starts, loc, weights, check_cuda_metadata=check)
            stream.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph, stream=stream):
                for _ in range(50):
                    output = ms_deform_attn(
                        value, shapes, starts, loc, weights, check_cuda_metadata=check
                    )
            graphs[check] = graph
            outputs[check] = output
            graph.replay()
        torch.testing.assert_close(outputs[False], outputs[True], atol=0, rtol=0)
        rng = random.Random(31)
        for repeat in range(7):
            order = [False, True]
            rng.shuffle(order)
            for check in order:
                graphs[check].replay()
                timings = []
                for _ in range(5):
                    begin, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
                    begin.record()
                    graphs[check].replay()
                    end.record()
                    end.synchronize()
                    timings.append(begin.elapsed_time(end) * 1000 / 50)
                rows.append(dict(case=case, check_cuda_metadata=check, repeat=repeat,
                                 graph_us=statistics.median(timings), samples_us=timings))
stream.synchronize()
report = dict(torch=torch.__version__, cuda=torch.version.cuda,
              gpu=torch.cuda.get_device_name(), dtype="float32", batch=2,
              canonical_binary=dict(path=_C.__file__, sha256=hashlib.sha256(Path(_C.__file__).read_bytes()).hexdigest()),
              measurements=rows, output_modes_bitwise_equal=True,
              notes="Forward CUDA Graph only; same inputs/stream; 50 calls per replay, 5 samples, 7 shuffled paired repetitions; launch bounds unchanged")
Path('/workspace/ci/results/toggle-benchmark.json').write_text(json.dumps(report, indent=2)+'\n')
for case in ('decoder', 'encoder'):
    print(case, {check: statistics.median(row['graph_us'] for row in rows if row['case']==case and row['check_cuda_metadata']==check) for check in (False, True)})
