#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
exec > >(tee /workspace/ci/results/candidate-build.log) 2>&1
export PATH=/workspace/ci/profile-env/bin:$PATH
export PYTHONUNBUFFERED=1 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9 CUDA_HOME=/usr/local/cuda FORCE_CUDA=1 FORCE_OPENMP=1
tar -xzf diagnostics/candidate.tar.gz -C /workspace/ci/source
cp diagnostics/candidate-sources.json /workspace/ci/results/candidate-sources.json
cp diagnostics/candidate.patch /workspace/ci/results/candidate.patch
mkdir -p /workspace/ci/results/wheels
python -m pip wheel --no-build-isolation --no-deps . -w /workspace/ci/results/wheels
python -m pip install --force-reinstall --no-deps /workspace/ci/results/wheels/*.whl
python -c 'import torch; from torch_ms_deform_attn import _C; print(torch.__version__, _C.__file__); assert _C.with_cuda; assert _C._check_cuda_indexing([2,5440,8,32,4,5440,4],64)[6] == 1'
printf 'CANDIDATE READY\n'
