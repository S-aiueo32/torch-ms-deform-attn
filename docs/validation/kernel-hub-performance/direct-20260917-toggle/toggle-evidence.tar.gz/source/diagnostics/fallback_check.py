#!/usr/bin/env python3
"""Build an isolated forced-int64 CUDA copy and exercise existing GPU oracles.

The installed package is never replaced. Only the copied host index-selection
predicate differs from the candidate; CUDA floating-point code is unchanged.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
import traceback
import unittest

import torch


MODULE_NAME = "_msda_int64_diagnostic"
CUDA_FILES = (
    "csrc/cuda/index_utils.h",
    "csrc/cuda/ms_deform_attn_cuda.h",
    "csrc/cuda/ms_deform_im2col_cuda.cuh",
    "csrc/cuda/ms_deform_attn_cuda.cu",
)
TEST_FILES = ("tests/test_cuda.py", "tests/sampling_cases.py")
BINDING = r"""
#include <ATen/ATen.h>
#include <torch/csrc/utils/pybind.h>
#include <pybind11/stl.h>
#include "cuda/index_utils.h"

#include "cuda/ms_deform_attn_cuda.h"


PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
  module.def("forward", &ms_deform_attn_cuda_forward);
  module.def("backward", &ms_deform_attn_cuda_backward);
  module.def("check_indexing", &ms_deform_attn::check_cuda_indexing);
}
"""


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def build(source: Path, output: Path):
    from torch.utils.cpp_extension import load

    copied = output / "source"
    original_hashes = {}
    copied_hashes = {}
    for relative in CUDA_FILES:
        original = source / relative
        destination = copied / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        content = original.read_text()
        if relative.endswith("index_utils.h"):
            needle = "const bool use_int32 ="
            if content.count(needle) != 1:
                raise RuntimeError("Expected exactly one candidate int32 selection predicate")
            content = content.replace(needle, "const bool use_int32 = false &&", 1)
        destination.write_text(content)
        original_hashes[relative] = digest(original)
        copied_hashes[relative] = digest(destination)
    binding = copied / "binding.cpp"
    binding.write_text(BINDING)
    build_dir = output / "build"
    build_dir.mkdir(exist_ok=True)
    manifest = {
        "status": "building",
        "module": MODULE_NAME,
        "source_root": str(source),
        "candidate_sources_sha256": original_hashes,
        "diagnostic_sources_sha256": copied_hashes,
        "test_sources_sha256": {name: digest(source / name) for name in TEST_FILES},
        "binding_sha256": digest(binding),
        "only_candidate_change": "const bool use_int32 = false && (original predicate)",
        "extra_cflags": ["-O3"],
        "extra_cuda_cflags": ["-O3", "-lineinfo"],
        "torch_version": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "cuda_arch_list": os.environ.get("TORCH_CUDA_ARCH_LIST"),
    }
    write_json(output / "manifest.json", manifest)
    module = load(
        name=MODULE_NAME,
        sources=[str(binding), str(copied / CUDA_FILES[-1])],
        extra_include_paths=[str(copied / "csrc")],
        extra_cflags=manifest["extra_cflags"],
        extra_cuda_cflags=manifest["extra_cuda_cflags"],
        build_directory=str(build_dir),
        with_cuda=True,
        verbose=True,
    )
    artifact = Path(module.__file__).resolve()
    manifest.update(status="built", artifact=str(artifact), artifact_sha256=digest(artifact))
    write_json(output / "manifest.json", manifest)
    return module, manifest


def load_built(source: Path, output: Path):
    manifest = json.loads((output / "manifest.json").read_text())
    if manifest["status"] != "built":
        raise RuntimeError("The diagnostic build has not completed")
    for relative, expected in manifest["candidate_sources_sha256"].items():
        if digest(source / relative) != expected:
            raise RuntimeError(f"Candidate changed since fallback build: {relative}")
    for relative, expected in manifest["test_sources_sha256"].items():
        if digest(source / relative) != expected:
            raise RuntimeError(f"Test changed since fallback build: {relative}")
    artifact = Path(manifest["artifact"])
    if digest(artifact) != manifest["artifact_sha256"]:
        raise RuntimeError("Diagnostic binary hash mismatch")
    spec = importlib.util.spec_from_file_location(MODULE_NAME, artifact)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, manifest


class JSONResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.subtests = []

    def addSubTest(self, test, subtest, error):
        record = {
            "test": test.id(),
            "parameters": {str(key): str(value) for key, value in subtest.params.items()},
            "passed": error is None,
        }
        if error is not None:
            record["failure"] = self._exc_info_to_string(error, test)
        self.subtests.append(record)
        super().addSubTest(test, subtest, error)


def check(source: Path, output: Path, module, manifest):
    if not torch.cuda.is_available():
        raise RuntimeError("A CUDA GPU is required for fallback execution")
    # Verify the compiled diagnostic really chooses int64 for tiny inputs.
    probe_plan = module.check_indexing([1, 1, 1, 1, 1, 1, 1], 1)
    if len(probe_plan) != 7 or probe_plan[6] != 0:
        raise RuntimeError(f"Forced fallback selection was not compiled: {probe_plan}")

    class FallbackFunction(torch.autograd.Function):
        @staticmethod
        def forward(ctx, value, shapes, starts, locations, weights, step, check):
            inputs = tuple(x.contiguous() for x in (value, shapes, starts, locations, weights))
            ctx.save_for_backward(*inputs)
            ctx.step = step
            ctx.check = check
            return module.forward(*inputs, step, check)

        @staticmethod
        def backward(ctx, grad_output):
            grad_value, grad_locations, grad_weights = module.backward(
                *ctx.saved_tensors, grad_output.contiguous(), ctx.step, ctx.check
            )
            return grad_value, None, None, grad_locations, grad_weights, None, None

    def fallback(value, shapes, starts, locations, weights, im2col_step=64, *, check_cuda_metadata=False):
        return FallbackFunction.apply(value, shapes, starts, locations, weights, im2col_step, check_cuda_metadata)

    sys.path.insert(0, str(source / "tests"))
    import sampling_cases
    import test_cuda

    # These tests compare forward and all three gradients with independent
    # grid_sample-based reference paths. Patching only their callable preserves
    # input distributions, tolerances, padding/collision cases, and chunk tests.
    sampling_cases.ms_deform_attn = fallback
    test_cuda.ms_deform_attn = fallback
    names = (
        "test_reference_forward_backward",
        "test_partial_batch_chunk",
        "test_padding_support_and_channel_sizes",
        "test_offsets_collisions_and_noncontiguous_metadata",
    )
    suite = unittest.TestSuite(test_cuda.CUDAAttentionTest(name) for name in names)
    with (output / "checks.log").open("w") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=JSONResult).run(suite)
    torch.cuda.synchronize()
    # Reject accidentally skipped tests, including a CPU-only installed product.
    passed = result.wasSuccessful() and not result.skipped and len(result.subtests) == 127
    report = {
        "status": "passed" if passed else "failed",
        "forced_index_plan": probe_plan,
        "torch_version": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "python": platform.python_version(),
        "device_name": torch.cuda.get_device_name(),
        "device_capability": torch.cuda.get_device_capability(),
        "tests_run": result.testsRun,
        "expected_subtests": 127,
        "subtests": result.subtests,
        "failures": [{"test": test.id(), "detail": detail} for test, detail in result.failures],
        "errors": [{"test": test.id(), "detail": detail} for test, detail in result.errors],
        "skipped": [{"test": test.id(), "reason": reason} for test, reason in result.skipped],
        "manifest": manifest,
        "scope": "Forced-int64 forward and all three first-order gradients, both FP32 and FP64",
    }
    write_json(output / "report.json", report)
    print(json.dumps({"status": report["status"], "subtests": len(result.subtests), "output": str(output)}))
    return passed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("/workspace/ci/source"))
    parser.add_argument("--output-dir", type=Path, default=Path("/workspace/ci/results/fallback"))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--build", "--build-only", dest="build_only", action="store_true")
    mode.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    try:
        module, manifest = load_built(source, output) if args.check_only else build(source, output)
        if args.build_only:
            print(json.dumps({"status": "built", "artifact": manifest["artifact"]}))
            return 0
        return 0 if check(source, output, module, manifest) else 1
    except Exception:
        error = traceback.format_exc()
        write_json(output / "error.json", {"status": "error", "traceback": error})
        print(error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
