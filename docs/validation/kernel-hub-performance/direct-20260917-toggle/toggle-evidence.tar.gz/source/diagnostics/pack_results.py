import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/workspace/ci')
results = root / 'results'
cuda = json.loads((results / 'cuda-tests.json').read_text())
assert cuda['success'] and cuda['failures'] == cuda['errors'] == 0
fallback = json.loads((results / 'fallback/report.json').read_text())
assert fallback['status'] == 'passed' and len(fallback['subtests']) == 127
adapter = json.loads((results / 'adapter/adapter-check.json').read_text())
assert adapter['completed'] and adapter['checks']['checked_flag_in_aot_forward_and_backward']
benchmark = json.loads((results / 'toggle-benchmark.json').read_text())
assert benchmark['output_modes_bitwise_equal'] and len(benchmark['measurements']) == 28
binary = json.loads((results / 'binary/binary_summary.json').read_text())
assert len(binary['binaries']) == 1 and binary['binaries'][0]['matches_report_sha256']
assert not binary['binaries'][0]['warnings']
for name in ('memcheck', 'racecheck', 'synccheck', 'initcheck'):
    log = (results / f'sanitizer-{name}.log').read_text()
    assert '\nOK\n' in log
    assert ('0 errors, 0 warnings' if name == 'racecheck' else 'ERROR SUMMARY: 0 errors') in log
sources = json.loads((results / 'candidate-sources.json').read_text())['sha256']
assert all(hashlib.sha256((root / 'source' / path).read_bytes()).hexdigest() == expected
           for path, expected in sources.items())
files = []
suffixes = {'.json', '.log', '.txt', '.py', '.sh', '.cpp', '.h', '.cuh', '.cu', '.toml', '.ninja', '.patch', '.gz'}
for parent in (results, root / 'source/diagnostics'):
    for path in parent.rglob('*'):
        if path.is_file() and path.suffix in suffixes and path.name not in ('toggle-evidence.tar.gz', 'evidence-manifest.json', 'error.json'):
            files.append(path)
files = sorted(set(files))
manifest = {str(path.relative_to(root)): dict(bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in files}
manifest_path = results / 'evidence-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
archive = results / 'toggle-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as bundle:
    for path in files + [manifest_path]:
        bundle.add(path, arcname=str(path.relative_to(root)), recursive=False)
print(json.dumps(dict(members=len(files)+1, bytes=archive.stat().st_size,
                     sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
