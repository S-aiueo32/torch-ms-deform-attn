#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
export PATH=/workspace/ci/profile-env/bin:$PATH
export PYTHONUNBUFFERED=1 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9 CUDA_HOME=/usr/local/cuda
export CUDA_CHECKS_SOURCE_SHA=2d604d2d9e2871ce2dc957278bbdae211e4b3fa8 FORCE_CUDA=1 FORCE_OPENMP=1
python scripts/cuda_test_report.py --output /workspace/ci/results/cuda-tests.json > /workspace/ci/results/cuda-tests.log 2>&1
for msda_tool in memcheck racecheck synccheck initcheck; do
  (cd tests && compute-sanitizer --tool "$msda_tool" --error-exitcode 1 --target-processes all \
    python -m unittest -v test_cuda.CUDAAttentionTest.test_reference_forward_backward \
      test_cuda.CUDAAttentionTest.test_partial_batch_chunk \
      test_cuda.CUDAAttentionTest.test_padding_support_and_channel_sizes \
      test_cuda.CUDAAttentionTest.test_offsets_collisions_and_noncontiguous_metadata) \
    > "/workspace/ci/results/sanitizer-$msda_tool.log" 2>&1
done
printf 'VALIDATION PASSED\n'
