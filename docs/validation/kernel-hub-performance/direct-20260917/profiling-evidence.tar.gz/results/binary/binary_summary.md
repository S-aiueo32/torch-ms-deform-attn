# Exact-binary CUDA inspection

Static SASS instruction counts describe the compiled instruction listing, not executed instructions, dynamic spill traffic, or elapsed-time attribution. Loops, branch paths and predication change runtime counts.

Register and local-memory sizes are compiled resource declarations. LDL/STL indicate local-memory instructions; local memory can have purposes besides spills.

Requested architecture: `sm_89`. Only that architecture is included in the comparison table.

| Backend | Kernel | Architecture | Registers | Stack bytes | Local bytes | Static inst. | Integer | IADD3 | IMAD | IMAD.WIDE | LDL | STL |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| canonical | fwd, template index=int | sm_89 | 54 | 0 | 0 | 504 | 328 | 62 | 137 | 20 | 0 | 0 |
| canonical | fwd, template index=long | sm_89 | 55 | 0 | 0 | 624 | 419 | 82 | 197 | 26 | 0 | 0 |
| canonical | bwd, C=32 | sm_89 | 74 | 0 | 0 | 632 | 298 | 94 | 113 | 17 | 0 | 0 |
| hf | fwd, template index=absent | sm_89 | 39 | 0 | 0 | 240 | 148 | 26 | 70 | 5 | 0 | 0 |
| hf | bwd, C=32 | sm_89 | 47 | 0 | 0 | 432 | 148 | 62 | 34 | 7 | 0 | 0 |
| baseline | fwd, template index=int | sm_89 | 54 | 0 | 0 | 504 | 328 | 62 | 137 | 20 | 0 | 0 |
| baseline | fwd, template index=long | sm_89 | 55 | 0 | 0 | 624 | 419 | 82 | 197 | 26 | 0 | 0 |
| baseline | bwd, C=32 | sm_89 | 74 | 0 | 0 | 632 | 298 | 94 | 113 | 17 | 0 | 0 |
| int32 | fwd, template index=int | sm_89 | 42 | 0 | 0 | 312 | 209 | 32 | 99 | 9 | 0 | 0 |
| int32 | bwd, C=32 | sm_89 | 70 | 0 | 0 | 472 | 180 | 64 | 51 | 8 | 0 | 0 |
| no_metadata | fwd, template index=int | sm_89 | 55 | 0 | 0 | 424 | 268 | 56 | 113 | 17 | 0 | 0 |
| no_metadata | fwd, template index=long | sm_89 | 54 | 0 | 0 | 544 | 363 | 71 | 179 | 23 | 0 | 0 |
| no_metadata | bwd, C=32 | sm_89 | 74 | 0 | 0 | 584 | 261 | 89 | 94 | 16 | 0 | 0 |
| int32_no_metadata | fwd, template index=int | sm_89 | 41 | 0 | 0 | 232 | 151 | 26 | 77 | 5 | 0 | 0 |
| int32_no_metadata | bwd, C=32 | sm_89 | 68 | 0 | 0 | 432 | 147 | 63 | 32 | 7 | 0 | 0 |

## Binary provenance

- `canonical`: `/workspace/ci/profile-env/lib/python3.11/site-packages/torch_ms_deform_attn/_C.cpython-311-x86_64-linux-gnu.so`; SHA256 `1460eaef8c0548e265d710e71554b20ba560abab22cf20fdd2a29883a305745b`; measured-report hash match: `True`.
- `hf`: `/home/ci/.cache/huggingface/hub/blobs/7d/7d2a02fde1afb32bee02103a78562d1d7e71a0be3ac3b0f1848c5303d8c89a79`; SHA256 `1a5053e022f3e5840ca9f40d361b5356ef0beeefdd8686029378dd4a7284b959`; measured-report hash match: `True`.
- `baseline`: `/workspace/ci/variants/baseline/build/msda_diagnostic_baseline.so`; SHA256 `fad247e95814c84a64862b66722bfd5f5113a7d326598f521413e551468c6261`; measured-report hash match: `None`.
- `int32`: `/workspace/ci/variants/int32/build/msda_diagnostic_int32.so`; SHA256 `9051fd41cefd9ab2b1fea52b20b274e0f2ca73d2c4b9579bc54b8c0ade783c36`; measured-report hash match: `None`.
- `no_metadata`: `/workspace/ci/variants/no_metadata/build/msda_diagnostic_no_metadata.so`; SHA256 `29de280b704d9e9e5b17ce50e6578afbcc4a942b21ad1ce9fe4b7ee83849e424`; measured-report hash match: `None`.
- `int32_no_metadata`: `/workspace/ci/variants/int32_no_metadata/build/msda_diagnostic_int32_no_metadata.so`; SHA256 `63ca634359e5569c61956d3677bd63915c27892026f88d2c69eb1cd4e742c015`; measured-report hash match: `None`.
