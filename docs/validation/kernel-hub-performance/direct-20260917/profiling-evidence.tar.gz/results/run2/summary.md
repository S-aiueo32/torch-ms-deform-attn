# PR #16 CUDA profiling summary

GPU: NVIDIA L4; PyTorch: 2.10.0+cu126; CUDA: 12.6.

Status: complete.
Wall and graph times are microseconds. Values are medians of repeat medians; ratios above 1 are slower than the named reference. Baseline reference: `baseline`.

Graph timing largely removes Python/dispatcher enqueue overhead, but includes GPU casts, allocations captured as operations, fills and kernels. Wall minus graph is not a direct measurement of host overhead.

HF exact requested revision loaded: `True`; loader arguments: `{"revision": "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"}`.

## decoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 63.59 [63.11, 63.92] | 57.73 | 1.000 | 1.000 | 0.969 | 0.937 |
| canonical | 5 | 65.70 [64.47, 66.32] | 61.55 | 1.033 | 1.066 | 1.001 | 0.999 |
| canonical_no_fill_defaults | 5 | 65.61 [65.45, 66.19] | 61.55 | 1.032 | 1.066 | 1.000 | 0.999 |
| native_control | 5 | 65.69 [64.96, 76.69] | 61.69 | 1.033 | 1.069 | 1.001 | 1.001 |
| baseline | 5 | 65.62 [65.53, 66.37] | 61.61 | 1.032 | 1.067 | 1.000 | 1.000 |
| int32 | 5 | 63.31 [62.97, 63.81] | 59.50 | 0.996 | 1.031 | 0.965 | 0.966 |
| no_metadata | 5 | 63.97 [63.03, 64.67] | 60.43 | 1.006 | 1.047 | 0.975 | 0.981 |
| int32_no_metadata | 5 | 62.55 [61.81, 62.66] | 58.08 | 0.984 | 1.006 | 0.953 | 0.943 |

## decoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 404.27 [356.57, 512.51] | 172.18 | 1.000 | 1.000 | 1.015 | 0.933 |
| canonical | 5 | 454.85 [424.94, 508.19] | 171.04 | 1.125 | 0.993 | 1.142 | 0.927 |
| canonical_no_fill_defaults | 5 | 444.51 [397.38, 458.23] | 171.93 | 1.100 | 0.999 | 1.116 | 0.932 |
| native_control | 5 | 350.20 [291.24, 403.03] | 182.13 | 0.866 | 1.058 | 0.879 | 0.987 |
| baseline | 5 | 398.20 [250.27, 402.61] | 184.52 | 0.985 | 1.072 | 1.000 | 1.000 |
| int32 | 5 | 348.42 [341.14, 387.65] | 166.70 | 0.862 | 0.968 | 0.875 | 0.903 |
| no_metadata | 5 | 377.61 [349.59, 469.53] | 174.64 | 0.934 | 1.014 | 0.948 | 0.946 |
| int32_no_metadata | 5 | 304.19 [220.73, 361.46] | 187.08 | 0.752 | 1.087 | 0.764 | 1.014 |

## decoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 38.80 [38.27, 39.28] | 35.82 | 1.000 | 1.000 | 0.934 | 0.892 |
| canonical | 5 | 42.92 [41.43, 43.19] | 40.66 | 1.106 | 1.135 | 1.033 | 1.013 |
| canonical_no_fill_defaults | 5 | 42.08 [41.61, 43.15] | 39.85 | 1.084 | 1.113 | 1.013 | 0.993 |
| native_control | 5 | 42.87 [41.58, 43.03] | 40.70 | 1.105 | 1.136 | 1.032 | 1.014 |
| baseline | 5 | 41.56 [41.37, 42.04] | 40.14 | 1.071 | 1.121 | 1.000 | 1.000 |
| int32 | 5 | 39.15 [38.81, 40.01] | 37.61 | 1.009 | 1.050 | 0.942 | 0.937 |
| no_metadata | 5 | 40.07 [40.02, 41.50] | 38.23 | 1.033 | 1.067 | 0.964 | 0.952 |
| int32_no_metadata | 5 | 38.42 [37.31, 38.99] | 36.90 | 0.990 | 1.030 | 0.925 | 0.919 |

## decoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 214.71 [159.46, 251.85] | 132.94 | 1.000 | 1.000 | 1.175 | 0.872 |
| canonical | 5 | 259.67 [179.84, 329.62] | 136.77 | 1.209 | 1.029 | 1.421 | 0.897 |
| canonical_no_fill_defaults | 5 | 264.06 [192.59, 319.93] | 137.63 | 1.230 | 1.035 | 1.445 | 0.903 |
| native_control | 5 | 186.38 [168.85, 245.16] | 148.04 | 0.868 | 1.114 | 1.020 | 0.971 |
| baseline | 5 | 182.79 [167.45, 199.20] | 152.41 | 0.851 | 1.146 | 1.000 | 1.000 |
| int32 | 5 | 180.80 [161.58, 221.38] | 139.05 | 0.842 | 1.046 | 0.989 | 0.912 |
| no_metadata | 5 | 181.48 [167.95, 242.35] | 151.03 | 0.845 | 1.136 | 0.993 | 0.991 |
| int32_no_metadata | 5 | 189.40 [158.07, 222.07] | 142.94 | 0.882 | 1.075 | 1.036 | 0.938 |

## encoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 716.32 [708.37, 725.77] | 741.65 | 1.000 | 1.000 | 0.912 | 0.922 |
| canonical | 5 | 792.70 [777.78, 803.77] | 808.93 | 1.107 | 1.091 | 1.009 | 1.005 |
| canonical_no_fill_defaults | 5 | 800.45 [775.47, 801.87] | 812.63 | 1.117 | 1.096 | 1.019 | 1.010 |
| native_control | 5 | 791.68 [775.14, 802.08] | 797.48 | 1.105 | 1.075 | 1.008 | 0.991 |
| baseline | 5 | 785.51 [766.40, 802.44] | 804.80 | 1.097 | 1.085 | 1.000 | 1.000 |
| int32 | 5 | 752.30 [613.54, 759.48] | 761.79 | 1.050 | 1.027 | 0.958 | 0.947 |
| no_metadata | 5 | 774.56 [681.71, 787.88] | 796.32 | 1.081 | 1.074 | 0.986 | 0.989 |
| int32_no_metadata | 5 | 727.58 [724.04, 741.47] | 741.47 | 1.016 | 1.000 | 0.926 | 0.921 |

## encoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 3039.20 [3029.35, 3047.20] | 3040.05 | 1.000 | 1.000 | 0.964 | 0.952 |
| canonical | 5 | 3153.09 [3123.13, 3184.64] | 3186.84 | 1.037 | 1.048 | 1.000 | 0.998 |
| canonical_no_fill_defaults | 5 | 3157.95 [3137.99, 3173.32] | 3187.73 | 1.039 | 1.049 | 1.001 | 0.998 |
| native_control | 5 | 3164.04 [3134.64, 3218.68] | 3191.92 | 1.041 | 1.050 | 1.003 | 1.000 |
| baseline | 5 | 3154.31 [3140.87, 3223.18] | 3193.18 | 1.038 | 1.050 | 1.000 | 1.000 |
| int32 | 5 | 3107.44 [3082.03, 3126.57] | 3100.84 | 1.022 | 1.020 | 0.985 | 0.971 |
| no_metadata | 5 | 3139.35 [3118.13, 3190.31] | 3151.48 | 1.033 | 1.037 | 0.995 | 0.987 |
| int32_no_metadata | 5 | 3062.23 [3047.62, 3064.04] | 3058.71 | 1.008 | 1.006 | 0.971 | 0.958 |

## encoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 600.33 [586.19, 600.96] | 599.60 | 1.000 | 1.000 | 0.919 | 0.903 |
| canonical | 5 | 654.97 [650.16, 662.92] | 667.94 | 1.091 | 1.114 | 1.003 | 1.006 |
| canonical_no_fill_defaults | 5 | 653.82 [524.59, 664.79] | 662.09 | 1.089 | 1.104 | 1.001 | 0.997 |
| native_control | 5 | 656.26 [648.21, 658.06] | 664.34 | 1.093 | 1.108 | 1.004 | 1.001 |
| baseline | 5 | 653.34 [621.97, 661.35] | 664.00 | 1.088 | 1.107 | 1.000 | 1.000 |
| int32 | 5 | 626.17 [612.13, 627.70] | 628.76 | 1.043 | 1.049 | 0.958 | 0.947 |
| no_metadata | 5 | 629.86 [627.60, 641.69] | 650.63 | 1.049 | 1.085 | 0.964 | 0.980 |
| int32_no_metadata | 5 | 607.59 [598.11, 610.62] | 613.41 | 1.012 | 1.023 | 0.930 | 0.924 |

## encoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 5 | 2933.83 [2899.96, 2953.06] | 2898.17 | 1.000 | 1.000 | 0.965 | 0.957 |
| canonical | 5 | 3036.33 [3024.63, 3090.96] | 3032.47 | 1.035 | 1.046 | 0.998 | 1.001 |
| canonical_no_fill_defaults | 5 | 3037.99 [3012.51, 3088.37] | 3022.30 | 1.036 | 1.043 | 0.999 | 0.998 |
| native_control | 5 | 3038.06 [3030.45, 3041.75] | 3028.69 | 1.036 | 1.045 | 0.999 | 1.000 |
| baseline | 5 | 3041.54 [3004.85, 3084.95] | 3029.62 | 1.037 | 1.045 | 1.000 | 1.000 |
| int32 | 5 | 2929.52 [2764.06, 2953.41] | 2939.88 | 0.999 | 1.014 | 0.963 | 0.970 |
| no_metadata | 5 | 3004.80 [3003.88, 3010.71] | 3011.41 | 1.024 | 1.039 | 0.988 | 0.994 |
| int32_no_metadata | 5 | 2901.10 [2888.72, 2925.43] | 2900.23 | 0.989 | 1.001 | 0.954 | 0.957 |

## CUDA profiler time per iteration

Profiler durations are collected separately and can be perturbed by profiling; auxiliary work includes casts and zero fills.

| Case / dtype / mode | Backend | Forward µs | Backward µs | Auxiliary µs | Total µs |
|---|---|---:|---:|---:|---:|
| decoder / float32 / forward | hf | 27.70 | 0.00 | 41.32 | 69.01 |
| decoder / float32 / forward | canonical | 32.40 | 0.00 | 32.40 | 64.81 |
| decoder / float32 / forward | canonical_no_fill_defaults | 32.94 | 0.00 | 32.94 | 65.88 |
| decoder / float32 / forward | native_control | 32.31 | 0.00 | 32.31 | 64.61 |
| decoder / float32 / forward | baseline | 32.88 | 0.00 | 32.88 | 65.77 |
| decoder / float32 / forward | int32 | 30.51 | 0.00 | 30.51 | 61.02 |
| decoder / float32 / forward | no_metadata | 31.52 | 0.00 | 31.52 | 63.04 |
| decoder / float32 / forward | int32_no_metadata | 29.15 | 0.00 | 29.15 | 58.30 |
| decoder / float32 / forward_backward | hf | 26.98 | 85.12 | 56.15 | 168.25 |
| decoder / float32 / forward_backward | canonical | 35.27 | 96.30 | 48.38 | 179.95 |
| decoder / float32 / forward_backward | canonical_no_fill_defaults | 31.89 | 89.54 | 43.80 | 165.24 |
| decoder / float32 / forward_backward | native_control | 31.79 | 89.03 | 43.66 | 164.48 |
| decoder / float32 / forward_backward | baseline | 32.38 | 89.44 | 44.18 | 166.00 |
| decoder / float32 / forward_backward | int32 | 29.65 | 86.22 | 41.43 | 157.31 |
| decoder / float32 / forward_backward | no_metadata | 30.91 | 88.02 | 42.70 | 161.62 |
| decoder / float32 / forward_backward | int32_no_metadata | 28.56 | 86.32 | 40.46 | 155.33 |
| encoder / float32 / forward | hf | 410.20 | 0.00 | 426.39 | 836.60 |
| encoder / float32 / forward | canonical | 367.35 | 0.00 | 367.35 | 734.71 |
| encoder / float32 / forward | canonical_no_fill_defaults | 364.84 | 0.00 | 364.84 | 729.69 |
| encoder / float32 / forward | native_control | 364.96 | 0.00 | 364.96 | 729.92 |
| encoder / float32 / forward | baseline | 363.94 | 0.00 | 363.94 | 727.88 |
| encoder / float32 / forward | int32 | 345.40 | 0.00 | 345.40 | 690.80 |
| encoder / float32 / forward | no_metadata | 353.06 | 0.00 | 353.06 | 706.12 |
| encoder / float32 / forward | int32_no_metadata | 332.28 | 0.00 | 332.28 | 664.57 |
| encoder / float32 / forward_backward | hf | 490.75 | 1510.69 | 547.71 | 2549.15 |
| encoder / float32 / forward_backward | canonical | 483.66 | 1618.25 | 518.02 | 2619.93 |
| encoder / float32 / forward_backward | canonical_no_fill_defaults | 474.10 | 1583.03 | 508.21 | 2565.34 |
| encoder / float32 / forward_backward | native_control | 463.87 | 1525.57 | 497.62 | 2487.07 |
| encoder / float32 / forward_backward | baseline | 464.39 | 1547.22 | 498.30 | 2509.91 |
| encoder / float32 / forward_backward | int32 | 445.05 | 1508.89 | 479.23 | 2433.17 |
| encoder / float32 / forward_backward | no_metadata | 450.93 | 1508.44 | 484.59 | 2443.96 |
| encoder / float32 / forward_backward | int32_no_metadata | 435.36 | 1520.52 | 469.76 | 2425.64 |

### Individual CUDA kernel durations

| Case / dtype / mode | Backend | Kernel | Calls/iteration | µs/iteration |
|---|---|---|---:|---:|
| decoder / float32 / forward | hf | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 39.90 |
| decoder / float32 / forward | hf | `void ms_deformable_im2col_gpu_kernel<float>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 27.70 |
| decoder / float32 / forward | hf | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 1.00 | 1.42 |
| decoder / float32 / forward | canonical | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 32.40 |
| decoder / float32 / forward | canonical | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 32.40 |
| decoder / float32 / forward | canonical_no_fill_defaults | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 32.94 |
| decoder / float32 / forward | canonical_no_fill_defaults | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 32.94 |
| decoder / float32 / forward | native_control | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 32.31 |
| decoder / float32 / forward | native_control | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 32.31 |
| decoder / float32 / forward | baseline | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 32.88 |
| decoder / float32 / forward | baseline | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 32.88 |
| decoder / float32 / forward | int32 | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 30.51 |
| decoder / float32 / forward | int32 | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 30.51 |
| decoder / float32 / forward | no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 31.52 |
| decoder / float32 / forward | no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 31.52 |
| decoder / float32 / forward | int32_no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 29.15 |
| decoder / float32 / forward | int32_no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 29.15 |
| decoder / float32 / forward_backward | hf | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(int, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 85.12 |
| decoder / float32 / forward_backward | hf | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 43.10 |
| decoder / float32 / forward_backward | hf | `void ms_deformable_im2col_gpu_kernel<float>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 26.98 |
| decoder / float32 / forward_backward | hf | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 4.00 | 13.05 |
| decoder / float32 / forward_backward | canonical | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 96.30 |
| decoder / float32 / forward_backward | canonical | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 35.27 |
| decoder / float32 / forward_backward | canonical | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 35.27 |
| decoder / float32 / forward_backward | canonical | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 13.11 |
| decoder / float32 / forward_backward | canonical_no_fill_defaults | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 89.54 |
| decoder / float32 / forward_backward | canonical_no_fill_defaults | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 31.89 |
| decoder / float32 / forward_backward | canonical_no_fill_defaults | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 31.89 |
| decoder / float32 / forward_backward | canonical_no_fill_defaults | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 11.91 |
| decoder / float32 / forward_backward | native_control | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 89.03 |
| decoder / float32 / forward_backward | native_control | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 31.79 |
| decoder / float32 / forward_backward | native_control | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 31.79 |
| decoder / float32 / forward_backward | native_control | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 11.88 |
| decoder / float32 / forward_backward | baseline | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 89.44 |
| decoder / float32 / forward_backward | baseline | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 32.38 |
| decoder / float32 / forward_backward | baseline | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 32.38 |
| decoder / float32 / forward_backward | baseline | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 11.79 |
| decoder / float32 / forward_backward | int32 | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(int, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 86.22 |
| decoder / float32 / forward_backward | int32 | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 29.65 |
| decoder / float32 / forward_backward | int32 | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 29.65 |
| decoder / float32 / forward_backward | int32 | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 11.79 |
| decoder / float32 / forward_backward | no_metadata | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 88.02 |
| decoder / float32 / forward_backward | no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 30.91 |
| decoder / float32 / forward_backward | no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 30.91 |
| decoder / float32 / forward_backward | no_metadata | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 11.79 |
| decoder / float32 / forward_backward | int32_no_metadata | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(int, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 1.00 | 86.32 |
| decoder / float32 / forward_backward | int32_no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 1.00 | 28.56 |
| decoder / float32 / forward_backward | int32_no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 1.00 | 28.56 |
| decoder / float32 / forward_backward | int32_no_metadata | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.00 | 11.90 |
| encoder / float32 / forward | hf | `MSDA_DIAGNOSTIC_ITERATION` | 0.90 | 418.58 |
| encoder / float32 / forward | hf | `void ms_deformable_im2col_gpu_kernel<float>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.90 | 410.20 |
| encoder / float32 / forward | hf | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 0.80 | 7.82 |
| encoder / float32 / forward | canonical | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 367.35 |
| encoder / float32 / forward | canonical | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 367.35 |
| encoder / float32 / forward | canonical_no_fill_defaults | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 364.84 |
| encoder / float32 / forward | canonical_no_fill_defaults | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 364.84 |
| encoder / float32 / forward | native_control | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 364.96 |
| encoder / float32 / forward | native_control | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 364.96 |
| encoder / float32 / forward | baseline | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 363.94 |
| encoder / float32 / forward | baseline | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 363.94 |
| encoder / float32 / forward | int32 | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 345.40 |
| encoder / float32 / forward | int32 | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 345.40 |
| encoder / float32 / forward | no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 353.06 |
| encoder / float32 / forward | no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 353.06 |
| encoder / float32 / forward | int32_no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.70 | 332.28 |
| encoder / float32 / forward | int32_no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 0.70 | 332.28 |
| encoder / float32 / forward_backward | hf | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(int, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1510.69 |
| encoder / float32 / forward_backward | hf | `MSDA_DIAGNOSTIC_ITERATION` | 0.90 | 502.88 |
| encoder / float32 / forward_backward | hf | `void ms_deformable_im2col_gpu_kernel<float>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.90 | 490.75 |
| encoder / float32 / forward_backward | hf | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 3.60 | 44.83 |
| encoder / float32 / forward_backward | canonical | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1618.25 |
| encoder / float32 / forward_backward | canonical | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 483.66 |
| encoder / float32 / forward_backward | canonical | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 483.66 |
| encoder / float32 / forward_backward | canonical | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 34.36 |
| encoder / float32 / forward_backward | canonical_no_fill_defaults | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1583.03 |
| encoder / float32 / forward_backward | canonical_no_fill_defaults | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 474.10 |
| encoder / float32 / forward_backward | canonical_no_fill_defaults | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 474.10 |
| encoder / float32 / forward_backward | canonical_no_fill_defaults | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 34.11 |
| encoder / float32 / forward_backward | native_control | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1525.57 |
| encoder / float32 / forward_backward | native_control | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 463.87 |
| encoder / float32 / forward_backward | native_control | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 463.87 |
| encoder / float32 / forward_backward | native_control | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 33.74 |
| encoder / float32 / forward_backward | baseline | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1547.22 |
| encoder / float32 / forward_backward | baseline | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 464.39 |
| encoder / float32 / forward_backward | baseline | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 464.39 |
| encoder / float32 / forward_backward | baseline | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 33.90 |
| encoder / float32 / forward_backward | int32 | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(int, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1508.89 |
| encoder / float32 / forward_backward | int32 | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 445.05 |
| encoder / float32 / forward_backward | int32 | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 445.05 |
| encoder / float32 / forward_backward | int32 | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 34.18 |
| encoder / float32 / forward_backward | no_metadata | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(long, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1508.44 |
| encoder / float32 / forward_backward | no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(long, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 450.93 |
| encoder / float32 / forward_backward | no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 450.93 |
| encoder / float32 / forward_backward | no_metadata | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 33.66 |
| encoder / float32 / forward_backward | int32_no_metadata | `void ms_deformable_col2im_gpu_kernel_shm_blocksize_aware_reduce_v1<float, 32u>(int, float const*, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*, float*, float*)` | 0.90 | 1520.52 |
| encoder / float32 / forward_backward | int32_no_metadata | `void ms_deformable_im2col_gpu_kernel<float, int>(int, float const*, long const*, long const*, float const*, float const*, int, int, int, int, int, int, int, float*)` | 0.80 | 435.36 |
| encoder / float32 / forward_backward | int32_no_metadata | `MSDA_DIAGNOSTIC_ITERATION` | 0.80 | 435.36 |
| encoder / float32 / forward_backward | int32_no_metadata | `void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::array<char*, 1ul> >(int, at::native::FillFunctor<float>, std::array<char*, 1ul>)` | 2.70 | 34.40 |

## ptxas FP32 forward and C=32 backward resources

Spill byte counts are static compiler reports; they do not measure dynamic spill traffic. Rebuilt baseline includes both int32 and int64 forward decomposition specializations; the small benchmark selects int32.

| Variant | Kernel | Architecture | Registers/thread | Stack bytes | Spill stores | Spill loads |
|---|---|---|---:|---:|---:|---:|
| baseline | backward, C=32 | sm_89 | 74 | 0 | 0 | 0 |
| baseline | forward, index=int | sm_89 | 54 | 0 | 0 | 0 |
| baseline | forward, index=long | sm_89 | 55 | 0 | 0 | 0 |
| int32 | backward, C=32 | sm_89 | 70 | 0 | 0 | 0 |
| int32 | forward, index=int | sm_89 | 42 | 0 | 0 | 0 |
| no_metadata | backward, C=32 | sm_89 | 74 | 0 | 0 | 0 |
| no_metadata | forward, index=int | sm_89 | 55 | 0 | 0 | 0 |
| no_metadata | forward, index=long | sm_89 | 54 | 0 | 0 | 0 |
| int32_no_metadata | backward, C=32 | sm_89 | 68 | 0 | 0 | 0 |
| int32_no_metadata | forward, index=int | sm_89 | 41 | 0 | 0 | 0 |

Correctness: 32/32 backend/case/dtype qualifications passed.
