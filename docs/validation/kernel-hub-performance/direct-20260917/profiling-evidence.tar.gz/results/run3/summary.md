# PR #16 CUDA profiling summary

GPU: NVIDIA L4; PyTorch: 2.10.0+cu126; CUDA: 12.6.

Status: complete.
Wall and graph times are microseconds. Values are medians of repeat medians; ratios above 1 are slower than the named reference. Baseline reference: `baseline`.

Graph timing largely removes Python/dispatcher enqueue overhead, but includes GPU casts, allocations captured as operations, fills and kernels. Wall minus graph is not a direct measurement of host overhead.

HF exact requested revision loaded: `True`; loader arguments: `{"revision": "abfd4042216fa4f84c9c5c4e3e844a3143c70ad5"}`.

## encoder / float16 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 750.95 [738.78, 755.04] | 733.31 | 1.000 | 1.000 | 0.910 | 0.918 |
| native_control | 7 | 824.60 [820.45, 828.78] | 822.88 | 1.098 | 1.122 | 0.999 | 1.030 |
| baseline | 7 | 825.04 [817.82, 832.29] | 798.83 | 1.099 | 1.089 | 1.000 | 1.000 |
| int32 | 7 | 791.58 [790.54, 809.84] | 776.27 | 1.054 | 1.059 | 0.959 | 0.972 |
| no_metadata | 7 | 805.05 [804.06, 811.67] | 786.02 | 1.072 | 1.072 | 0.976 | 0.984 |
| int32_no_metadata | 7 | 773.04 [763.74, 774.89] | 750.43 | 1.029 | 1.023 | 0.937 | 0.939 |

## encoder / float16 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 3076.52 [3073.33, 3104.17] | 3061.07 | 1.000 | 1.000 | 0.943 | 0.948 |
| native_control | 7 | 3259.99 [3196.19, 3266.56] | 3241.92 | 1.060 | 1.059 | 0.999 | 1.004 |
| baseline | 7 | 3263.75 [3193.01, 3276.28] | 3227.60 | 1.061 | 1.054 | 1.000 | 1.000 |
| int32 | 7 | 3158.26 [3141.79, 3179.03] | 3150.48 | 1.027 | 1.029 | 0.968 | 0.976 |
| no_metadata | 7 | 3218.84 [3185.40, 3222.35] | 3207.11 | 1.046 | 1.048 | 0.986 | 0.994 |
| int32_no_metadata | 7 | 3116.90 [3096.83, 3130.59] | 3116.29 | 1.013 | 1.018 | 0.955 | 0.966 |

## encoder / float32 / forward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 597.79 [591.60, 608.89] | 587.24 | 1.000 | 1.000 | 0.901 | 0.896 |
| native_control | 7 | 666.38 [655.33, 668.84] | 664.68 | 1.115 | 1.132 | 1.004 | 1.014 |
| baseline | 7 | 663.45 [655.01, 665.19] | 655.33 | 1.110 | 1.116 | 1.000 | 1.000 |
| int32 | 7 | 627.31 [616.56, 631.69] | 623.74 | 1.049 | 1.062 | 0.946 | 0.952 |
| no_metadata | 7 | 641.55 [635.01, 642.23] | 639.58 | 1.073 | 1.089 | 0.967 | 0.976 |
| int32_no_metadata | 7 | 606.92 [594.77, 611.89] | 606.13 | 1.015 | 1.032 | 0.915 | 0.925 |

## encoder / float32 / forward_backward

| Backend | Reps | Wall µs [repeat range] | Graph µs | Wall/HF | Graph/HF | Wall/base | Graph/base |
|---|---:|---:|---:|---:|---:|---:|---:|
| hf | 7 | 2921.94 [2898.90, 2964.40] | 2907.09 | 1.000 | 1.000 | 0.955 | 0.950 |
| native_control | 7 | 3052.33 [2974.52, 3083.12] | 3061.24 | 1.045 | 1.053 | 0.997 | 1.000 |
| baseline | 7 | 3060.22 [3047.81, 3083.79] | 3059.80 | 1.047 | 1.053 | 1.000 | 1.000 |
| int32 | 7 | 2962.57 [2902.71, 2968.13] | 2949.11 | 1.014 | 1.014 | 0.968 | 0.964 |
| no_metadata | 7 | 3016.67 [2984.37, 3054.43] | 3009.97 | 1.032 | 1.035 | 0.986 | 0.984 |
| int32_no_metadata | 7 | 2922.83 [2916.32, 2942.40] | 2911.02 | 1.000 | 1.001 | 0.955 | 0.951 |

## ptxas FP32 forward and C=32 backward resources

Spill byte counts are static compiler reports; they do not measure dynamic spill traffic. Rebuilt baseline includes both int32 and int64 forward decomposition specializations; the small benchmark selects int32.

| Variant | Kernel | Architecture | Registers/thread | Stack bytes | Spill stores | Spill loads |
|---|---|---|---:|---:|---:|---:|
| baseline | backward, C=32 | sm_89 | 74 | 0 | 0 | 0 |
| baseline | forward, index=int | sm_89 | 54 | 0 | 0 | 0 |
| baseline | forward, index=long | sm_89 | 55 | 0 | 0 | 0 |
| int32 | backward, C=32 | sm_89 | 70 | 0 | 0 | 0 |
| int32 | forward, index=int | sm_89 | 42 | 0 | 0 | 0 |
| no_metadata | backward, C=32 | sm_89 | 74 | 0 | 0 | 0 |
| no_metadata | forward, index=int | sm_89 | 55 | 0 | 0 | 0 |
| no_metadata | forward, index=long | sm_89 | 54 | 0 | 0 | 0 |
| int32_no_metadata | backward, C=32 | sm_89 | 68 | 0 | 0 | 0 |
| int32_no_metadata | forward, index=int | sm_89 | 41 | 0 | 0 | 0 |

Correctness: 12/12 backend/case/dtype qualifications passed.
