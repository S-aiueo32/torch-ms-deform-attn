#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
exec > >(tee /workspace/ci/results/experiment.log) 2>&1
export PATH=/workspace/ci/profile-env/bin:$PATH
export PYTHONUNBUFFERED=1 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9 CUDA_HOME=/usr/local/cuda
python diagnostics/prepare_variants.py --repo . --output /workspace/ci/variants --build
cp /workspace/ci/variants/manifest.json /workspace/ci/results/variants-manifest.json
python diagnostics/probe.py --output-dir /workspace/ci/results/run1 --variants-dir /workspace/ci/variants
cp /workspace/ci/results/run1/report.json /workspace/ci/results/report-run1.json
tar -czf /workspace/ci/results/run1-traces.tar.gz -C /workspace/ci/results/run1 .
printf 'EXPERIMENT READY\n'
