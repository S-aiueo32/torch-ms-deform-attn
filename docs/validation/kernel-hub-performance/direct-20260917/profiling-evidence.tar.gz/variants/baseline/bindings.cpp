
#include <torch/extension.h>
#include "cuda/ms_deform_attn_cuda.h"
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("forward", &ms_deform_attn_cuda_forward);
  m.def("backward", &ms_deform_attn_cuda_backward);
  m.def("ms_deform_attn_forward", &ms_deform_attn_cuda_forward);
  m.def("ms_deform_attn_backward", &ms_deform_attn_cuda_backward);
}
