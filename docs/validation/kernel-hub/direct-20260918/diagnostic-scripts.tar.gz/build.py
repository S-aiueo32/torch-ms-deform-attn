import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import torch
from torch.utils.cpp_extension import load

root = Path('/workspace/ci/source')
out = Path('/workspace/ci/debug-build')
out.mkdir()
spec = importlib.util.spec_from_file_location('exporter', root/'kernel-hub/export.py')
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)
export = out/'export'
revision = (root/'diagnostics/revision.txt').read_text().strip()
exporter.export(export, revision=revision)
native = load(name='msda_pr17_native', sources=[str(export/'torch-ext/torch_binding.cpp'), str(export/'csrc/cuda/ms_deform_attn_cuda.cu')], extra_include_paths=[str(export/'csrc'), str(root/'diagnostics')], extra_cflags=['-O3'], extra_cuda_cflags=['-O3'], build_directory=str(out), with_cuda=True, verbose=True)
package = out/'candidate'
shutil.copytree(export/'torch-ext/deformable_detr', package)
shutil.copy2(native.__file__, package)
(package/'_ops.py').write_text('import torch\nfrom . import msda_pr17_native\nops = torch.ops.msda_pr17_native\ndef add_op_namespace_prefix(name):\n    return "msda_pr17_native::" + name\n')
(package/'metadata.json').write_text(json.dumps(dict(name='deformable-detr', id='msda_pr17_package', version=1, license='Apache-2.0', **{'python-depends':[], 'backend':{'type':'cuda','archs':['8.9']}})))
from kernels import get_local_kernel, get_kernel
sys.modules['msda_pr17_package.msda_pr17_native'] = native
candidate = get_local_kernel(package)
baseline = get_kernel('kernels-community/deformable-detr', revision='abfd4042216fa4f84c9c5c4e3e844a3143c70ad5')
(out/'paths.json').write_text(json.dumps({'candidate':str(package), 'baseline':str(Path(baseline.__file__).parent)}))
shutil.copy2(export/'UPSTREAM.json', '/workspace/ci/results/UPSTREAM.json')
print('DEBUG BUILD READY', flush=True)
