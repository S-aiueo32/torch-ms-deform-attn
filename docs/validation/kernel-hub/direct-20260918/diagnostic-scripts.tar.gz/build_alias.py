import json
from pathlib import Path
import shutil
import sys
from torch.utils.cpp_extension import load
base=Path('/workspace/ci/debug-build')
export=base/'export'
out=Path('/workspace/ci/exact-name-build')
out.mkdir()
name='_deformable_detr_cuda_2e7cdb5d36922b82f97b2f9b0155752c2a1b9efa'
native=load(name=name,sources=[str(export/'torch-ext/torch_binding.cpp'),str(export/'csrc/cuda/ms_deform_attn_cuda.cu')],extra_include_paths=[str(export/'csrc'),'/workspace/ci/source/diagnostics'],extra_cflags=['-O3'],extra_cuda_cflags=['-O3'],build_directory=str(out),with_cuda=True,verbose=True)
package=out/'candidate'
shutil.copytree(export/'torch-ext/deformable_detr',package)
shutil.copy2(native.__file__,package)
(package/'_ops.py').write_text(f'import torch\nfrom . import {name}\nops = torch.ops.{name}\ndef add_op_namespace_prefix(name):\n    return "{name}::" + name\n')
meta=json.loads((base/'candidate/metadata.json').read_text()); meta['id']=name
(package/'metadata.json').write_text(json.dumps(meta))
paths=json.loads((base/'paths.json').read_text()); paths['candidate']=str(package)
(base/'exact-paths.json').write_text(json.dumps(paths))
print('EXACT NAMESPACE BUILD READY',flush=True)
