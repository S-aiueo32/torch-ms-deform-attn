import json
from pathlib import Path
import sys
import torch
from kernels import get_local_kernel
root=Path('/workspace/ci/results')/sys.argv[1]
captures=torch.load(root/'captures.pt',weights_only=True)
paths=json.loads(Path('/workspace/ci/debug-build/paths.json').read_text())
candidate=get_local_kernel(Path(paths['candidate']))
baseline=get_local_kernel(Path(paths['baseline']))
report={}
def difference(a,b):
    a=a.float(); b=b.float()
    d=(a-b).abs()
    return {'max_abs':d.max().item(),'different':int(torch.count_nonzero(d)), 'elements':d.numel()}
def values(items):
    return [x['tensor'].cuda().contiguous() if isinstance(x,dict) else x for x in items]
for mode in ('forward','backward'):
    ca=captures.get('candidate:'+mode,[])
    ba=captures.get('baseline:ms_deform_attn_'+mode,[])
    rows=[]
    for index,(a,b) in enumerate(zip(ca,ba)):
        row={'call':index,'inputs':{}}
        for i,(x,y) in enumerate(zip(a['inputs'],b['inputs'])):
            if isinstance(x,dict) and isinstance(y,dict):
                row['inputs'][str(i)]={'candidate_stride':x['stride'],'baseline_stride':y['stride'],**difference(x['tensor'],y['tensor'])}
        outa=a['output'] if isinstance(a['output'],list) else [a['output']]
        outb=b['output'] if isinstance(b['output'],list) else [b['output']]
        row['outputs']=[difference(x['tensor'],y['tensor']) for x,y in zip(outa,outb)]
        for side,entry in (('candidate',a),('baseline',b)):
            inputs=values(entry['inputs'])[:6 if mode=='forward' else 7]
            x=getattr(candidate._registrations,mode)(*inputs)
            y=getattr(baseline._ops.ops,'ms_deform_attn_'+mode)(*inputs)
            xs=x if isinstance(x,(tuple,list)) else [x]
            ys=y if isinstance(y,(tuple,list)) else [y]
            row['shared_'+side+'_inputs']=[difference(xx,yy) for xx,yy in zip(xs,ys)]
        rows.append(row)
    report[mode]={'candidate_calls':len(ca),'baseline_calls':len(ba),'rows':rows}
(root/'operator-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
