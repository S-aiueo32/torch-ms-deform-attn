"""Diagnostic only: dump graphs and intercept compiled fallback calls after warmup."""
import argparse
import json
import os
from pathlib import Path
import sys
import traceback
import types
import torch

parser=argparse.ArgumentParser()
parser.add_argument('--capture', action='store_true')
parser.add_argument('--tag', default='original')
parser.add_argument('--prefix-matrix', action='store_true')
args=parser.parse_args()
root=Path('/workspace/ci/source')
out=Path('/workspace/ci/results')/args.tag
out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'kernel-hub/e2e'))
source=(root/'kernel-hub/e2e/rt_detr.py').read_text()
paths=json.loads(Path('/workspace/ci/debug-build/paths.json').read_text())
captures={}
originals=[]
graph_index=0
capture_enabled=False

def install_capture(module, role):
    if not capture_enabled:
        return
    for name in (('forward','backward') if role=='candidate' else ('ms_deform_attn_forward','ms_deform_attn_backward')):
        op = getattr(module._registrations,name) if role=='candidate' else getattr(module._ops.ops,name).default
        namespace, opname = op.name().split('::')
        packet=getattr(getattr(torch.ops,namespace),opname)
        def spy(*values, _op=op, _role=role, _name=name, **kw):
            result=_op(*values,**kw)
            def copied(v):
                if isinstance(v,torch.Tensor):
                    return {'tensor':v.detach().cpu().clone(), 'shape':list(v.shape),'stride':list(v.stride()),'dtype':str(v.dtype)}
                if isinstance(v,(list,tuple)):
                    return [copied(x) for x in v]
                return v
            captures.setdefault(_role+':'+_name,[]).append({'inputs':copied(values),'output':copied(result)})
            return result
        originals.append((packet, packet.default))
        packet.default=spy

def restore_capture():
    while originals:
        packet, original=originals.pop()
        packet.default=original

def wrap_compiler(compiler):
    def compile_graph(graph, inputs, **kwargs):
        global graph_index
        idx=graph_index
        graph_index+=1
        (out/f'graph-{idx}.txt').write_text(graph.code)
        return compiler(graph, inputs, **kwargs)
    return compile_graph

source=source.replace('compiler = lookup_backend(backend)', 'compiler = wrap_compiler(lookup_backend(backend))')
if args.capture:
    source=source.replace('    with torch.profiler.profile(', '    install_capture(module, "candidate")\n    with torch.profiler.profile(')
    source=source.replace('    names = {event.key:', '    restore_capture()\n    names = {event.key:')
    source=source.replace('        reference_eager = expected', '''        run_model(reference, candidate_pixels, labels, training=training,
                  amp_dtype=scalar_type if amp else None, execute=compiled_reference)
        install_capture(baseline_module, "baseline")
        reference_eager = expected''')
    source=source.replace('        if diagnostics is not None:\n            diagnostics["hf_compiled_vs_eager"]', '        restore_capture()\n        if diagnostics is not None:\n            diagnostics["hf_compiled_vs_eager"]')
module=types.ModuleType('diagnostic_rt_detr')
sys.modules[module.__name__]=module
module.__dict__.update(wrap_compiler=wrap_compiler,install_capture=install_capture,restore_capture=restore_capture)
exec(compile(source, str(root/'kernel-hub/e2e/rt_detr.py'),'exec'),module.__dict__)
torch.backends.cudnn.allow_tf32=False
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cuda.enable_flash_sdp(False)
torch.backends.cuda.enable_mem_efficient_sdp(False)
torch.backends.cuda.enable_cudnn_sdp(False)
torch.backends.cuda.enable_math_sdp(True)
diagnostics={}
report={'tag':args.tag,'capture':args.capture,'diagnostics':diagnostics}
try:
    if args.prefix_matrix:
        report['prefix_cases']=[]
        for training,backend in ((False,None),(False,'inductor'),(True,None)):
            report['prefix_cases'].append(module.run_case(Path(paths['candidate']),baseline_kernel_dir=Path(paths['baseline']),training=training,backend=backend,dtype='bf16',amp=True,numerics='controlled',diagnostics={},compile_reference=True))
            print(f'Prefix training={training} backend={backend} passed',flush=True)
    capture_enabled=True
    report['case']=module.run_case(Path(paths['candidate']),baseline_kernel_dir=Path(paths['baseline']),training=True,backend='inductor',dtype='bf16',amp=True,numerics='controlled',diagnostics=diagnostics,compile_reference=True)
    report['status']='passed'
except Exception:
    report['status']='failed'
    report['error']=traceback.format_exc()
    print(report['error'],flush=True)
finally:
    restore_capture()
    torch.save(captures,out/'captures.pt')
    report['capture_counts']={k:len(v) for k,v in captures.items()}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'captures':report['capture_counts']}),flush=True)
