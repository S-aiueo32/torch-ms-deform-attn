import json
from pathlib import Path
import shutil
from kernels import get_local_kernel, get_kernel
out=Path('/workspace/ci/debug-build')
candidate=get_local_kernel(out/'candidate')
baseline=get_kernel('kernels-community/deformable-detr',revision='abfd4042216fa4f84c9c5c4e3e844a3143c70ad5')
(out/'paths.json').write_text(json.dumps({'candidate':str(out/'candidate'),'baseline':str(Path(baseline.__file__).parent)}))
shutil.copy2(out/'export/UPSTREAM.json','/workspace/ci/results/UPSTREAM.json')
print('DEBUG BUILD READY',flush=True)
