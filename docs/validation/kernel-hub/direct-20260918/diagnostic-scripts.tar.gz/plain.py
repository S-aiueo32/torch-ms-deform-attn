import json
from pathlib import Path
import subprocess
import sys
tag=sys.argv[1] if len(sys.argv)>1 else 'plain'
paths=json.loads(Path('/workspace/ci/debug-build/'+('exact-paths.json' if tag=='exact' else 'paths.json')).read_text())
raise SystemExit(subprocess.run([sys.executable,'kernel-hub/e2e/rt_detr.py','--kernel-dir',paths['candidate'],'--baseline-kernel-dir',paths['baseline'],'--dtype','bf16','--autocast','--numerics','controlled','--compile-reference','--report',f'/workspace/ci/results/{tag}-bf16-amp.json']).returncode)
