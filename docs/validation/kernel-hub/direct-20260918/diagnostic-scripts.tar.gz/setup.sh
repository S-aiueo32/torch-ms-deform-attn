#!/usr/bin/env bash
set -euo pipefail
cd /workspace/ci/source
exec > >(tee /workspace/ci/results/setup.log) 2>&1
export PYTHONUNBUFFERED=1 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9 CUDA_HOME=/usr/local/cuda
nvidia-smi > /workspace/ci/results/nvidia-smi.txt
python3 -m venv /workspace/ci/debug-env
export PATH=/workspace/ci/debug-env/bin:$PATH
python -m pip install --no-cache-dir torch==2.10.0 torchvision==0.25.0 --index-url https://download.pytorch.org/whl/cu126
python -m pip install --no-cache-dir -r kernel-hub/e2e/requirements.txt 'setuptools>=77' wheel ninja numpy packaging
python -m pip freeze > /workspace/ci/results/python-packages.txt
python diagnostics/build.py
